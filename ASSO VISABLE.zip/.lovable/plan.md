## Vérification de la nouvelle clé Resend

1. **Tester l'envoi réel** via le formulaire de contact en mode automatisé (Playwright sur le sandbox local).
2. **Lire les logs serveur** pour confirmer qu'il n'y a plus d'erreur 403 "domain not verified".
3. **Si OK** : confirmer que tu reçois bien l'email à `contact@assovisible.fr` + l'email de confirmation à l'adresse du visiteur. Aucun changement de code n'est nécessaire.
4. **Si KO** : réactiver temporairement le bloc de diagnostic dans `src/lib/contact.functions.ts` pour interroger `/domains` avec la nouvelle clé et identifier précisément ce qu'elle voit (équipe, domaines listés, statut).

Aucune modification de code prévue à ce stade — uniquement un test de validation. Tu valides ?
import { Link } from "@tanstack/react-router";
import logoSrc from "@/assets/logo-assovisible.png";

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link to="/" className="flex items-center group" aria-label="AssoVisible accueil">
      <img
        src={logoSrc}
        alt="AssoVisible — Création de sites web pour le monde associatif"
        className={`h-9 md:h-11 lg:h-[3.3rem] w-auto ${light ? "brightness-0 invert" : ""}`}
      />
    </Link>
  );
}

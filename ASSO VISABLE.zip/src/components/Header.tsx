import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Menu, X, Phone } from "lucide-react";
import { Logo } from "./Logo";

const navLinks = [
  { to: "/", label: "Accueil" },
  { to: "/realisations", label: "Réalisations" },
  { to: "/services", label: "Services" },
  { to: "/a-propos", label: "À propos" },
  { to: "/blog", label: "Blog" },
  { to: "/contact", label: "Contact" },
] as const;

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 w-full transition-all duration-500 ${
        scrolled
          ? "glass shadow-[0_8px_30px_-12px_oklch(0.27_0.06_265_/_0.15)]"
          : "bg-transparent"
      }`}
    >
      <div className="container-prose flex h-16 md:h-20 items-center justify-between gap-6">
        <Logo />

        <nav className="hidden lg:flex items-center gap-8 font-sans text-[15px]">
          {navLinks.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              activeProps={{ className: "text-primary font-semibold" }}
              inactiveProps={{ className: "text-ink/70 hover:text-primary" }}
              activeOptions={{ exact: l.to === "/" }}
              className="transition-colors relative py-1.5 [&[data-status=active]]:after:content-[''] [&[data-status=active]]:after:absolute [&[data-status=active]]:after:left-0 [&[data-status=active]]:after:right-0 [&[data-status=active]]:after:-bottom-0.5 [&[data-status=active]]:after:h-[2px] [&[data-status=active]]:after:bg-gold"
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="hidden lg:flex items-center gap-4">
          <a
            href="tel:+33647474581"
            className="flex items-center gap-1.5 text-sm font-sans text-ink/70 hover:text-primary"
          >
            <Phone className="h-4 w-4" /> 06 47 47 45 81
          </a>
          <Link
            to="/contact"
            className="btn-gold !py-2.5 !px-5 !text-sm"
          >
            Devis gratuit
          </Link>
        </div>

        <button
          className="lg:hidden inline-flex items-center justify-center rounded-md p-2 text-primary"
          onClick={() => setOpen(true)}
          aria-label="Ouvrir le menu"
        >
          <Menu className="h-6 w-6" />
        </button>
      </div>

      {open && (
        <div className="fixed inset-0 z-50 bg-cream lg:hidden flex flex-col">
          <div className="container-prose flex h-20 items-center justify-between">
            <Logo />
            <button
              onClick={() => setOpen(false)}
              className="rounded-md p-2 text-primary"
              aria-label="Fermer le menu"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
          <nav className="container-prose flex flex-col gap-1 mt-8 font-display text-3xl">
            {navLinks.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                className="py-3 border-b border-border text-primary"
              >
                {l.label}
              </Link>
            ))}
            <Link
              to="/contact"
              onClick={() => setOpen(false)}
              className="mt-8 inline-flex items-center justify-center rounded-md bg-gold px-6 py-4 font-sans text-base font-semibold text-gold-foreground"
            >
              Devis gratuit
            </Link>
            <a
              href="tel:+33647474581"
              className="mt-4 flex items-center gap-2 text-base font-sans text-ink/70"
            >
              <Phone className="h-4 w-4" /> 06 47 47 45 81
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}

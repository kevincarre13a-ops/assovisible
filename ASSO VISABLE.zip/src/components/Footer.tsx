import { Link } from "@tanstack/react-router";
import { ShieldCheck, MapPin } from "lucide-react";
import { Logo } from "./Logo";

export function Footer() {
  return (
    <footer className="relative mesh-bg-dark text-cream/85 mt-24 overflow-hidden grain">
      <div aria-hidden className="absolute -top-32 -right-32 h-96 w-96 rounded-full bg-gold/15 blur-3xl animate-blob" />
      <div aria-hidden className="absolute -bottom-32 -left-32 h-96 w-96 rounded-full bg-sage/15 blur-3xl animate-blob" style={{ animationDelay: "5s" }} />
      <div className="relative container-wide py-16 grid gap-12 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <Logo light />
          <p className="mt-4 text-[15px] leading-relaxed text-cream/70 font-serif">
            L'agence web qui parle le langage des associations loi 1901.
            Des sites professionnels, durables et accompagnés.
          </p>
        </div>

        <div className="font-sans text-sm">
          <h4 className="font-display text-cream text-lg mb-4">Navigation</h4>
          <ul className="space-y-2.5">
            <li><Link to="/" className="hover:text-gold">Accueil</Link></li>
            <li><Link to="/realisations" className="hover:text-gold">Réalisations</Link></li>
            <li><Link to="/services" className="hover:text-gold">Services</Link></li>
            <li><Link to="/a-propos" className="hover:text-gold">À propos</Link></li>
            <li><Link to="/blog" className="hover:text-gold">Blog</Link></li>
            <li><Link to="/contact" className="hover:text-gold">Contact</Link></li>
          </ul>
        </div>

        <div className="font-sans text-sm">
          <h4 className="font-display text-cream text-lg mb-4">Contact</h4>
          <ul className="space-y-2.5">
            <li>06 47 47 45 81</li>
            <li>contact@assovisible.fr</li>
            <li className="flex items-start gap-2">
              <MapPin className="h-4 w-4 mt-1 shrink-0" />
              <span>France</span>
            </li>
          </ul>
        </div>

        <div className="font-sans text-sm">
          <h4 className="font-display text-cream text-lg mb-4">Garanties</h4>
          <ul className="space-y-3">
            <li className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-gold" /> Hébergement en France</li>
            <li className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-gold" /> Conforme RGPD</li>
            <li className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-gold" /> Satisfait ou remboursé 30j</li>
          </ul>
        </div>
      </div>

      <div className="relative border-t border-cream/10">
        <div className="container-wide py-6 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-cream/60 font-sans">
          <p>© {new Date().getFullYear()} AssoVisible. Tous droits réservés.</p>
          <div className="flex gap-5">
            <Link to="/mentions-legales" className="hover:text-gold">Mentions légales</Link>
            <Link to="/cgv" className="hover:text-gold">CGV</Link>
            <Link to="/confidentialite" className="hover:text-gold">Politique de confidentialité</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

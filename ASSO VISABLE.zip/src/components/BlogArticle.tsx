import { Link } from "@tanstack/react-router";
import { Sparkles, ArrowRight, Calendar, Clock, ArrowLeft } from "lucide-react";
import { Reveal } from "@/components/Reveal";
import { formatFrenchDate, type BlogPostMeta } from "@/lib/blog-posts";

interface BlogArticleProps {
  post: BlogPostMeta;
  children: React.ReactNode;
}

export function BlogArticle({ post, children }: BlogArticleProps) {
  return (
    <>
      <section className="relative py-20 mesh-bg grain overflow-hidden">
        <div aria-hidden className="absolute -top-20 right-1/4 h-72 w-72 rounded-full bg-sage/20 blur-3xl animate-blob" />
        <div aria-hidden className="absolute bottom-0 left-1/4 h-80 w-80 rounded-full bg-gold/20 blur-3xl animate-blob" style={{ animationDelay: "4s" }} />
        <div className="container-wide relative max-w-3xl mx-auto">
          <Link to="/blog" className="inline-flex items-center gap-2 text-sm font-sans text-ink/60 hover:text-primary transition">
            <ArrowLeft className="h-4 w-4" /> Retour au blog
          </Link>
          <span className="chip mt-6"><Sparkles className="h-3.5 w-3.5" /> {post.category}</span>
          <h1 className="mt-6 font-display text-4xl md:text-5xl lg:text-6xl tracking-tight leading-tight">
            {post.title}
          </h1>
          <div className="mt-6 flex flex-wrap items-center gap-5 text-sm font-sans text-ink/60">
            <span className="inline-flex items-center gap-1.5"><Calendar className="h-4 w-4" /> {formatFrenchDate(post.date)}</span>
            <span className="inline-flex items-center gap-1.5"><Clock className="h-4 w-4" /> {post.readingTime} de lecture</span>
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="container-wide max-w-3xl">
          <article className="font-serif text-[18px] leading-relaxed text-ink/85
            [&_h2]:font-display [&_h2]:text-3xl md:[&_h2]:text-4xl [&_h2]:text-primary [&_h2]:mt-14 [&_h2]:mb-4 [&_h2]:leading-tight
            [&_h3]:font-display [&_h3]:text-2xl [&_h3]:text-primary [&_h3]:mt-10 [&_h3]:mb-3
            [&_p]:mt-4
            [&_ul]:list-disc [&_ul]:pl-6 [&_ul]:space-y-2 [&_ul]:mt-4
            [&_ol]:list-decimal [&_ol]:pl-6 [&_ol]:space-y-2 [&_ol]:mt-4
            [&_a]:text-gold [&_a]:underline [&_a]:underline-offset-4
            [&_strong]:text-primary [&_strong]:font-semibold
            [&_blockquote]:border-l-4 [&_blockquote]:border-gold [&_blockquote]:pl-5 [&_blockquote]:italic [&_blockquote]:text-ink/70 [&_blockquote]:my-6">

            {children}
          </article>
        </div>
      </section>

      <section className="py-20">
        <div className="container-wide max-w-4xl">
          <Reveal>
            <div className="relative rounded-3xl overflow-hidden p-10 md:p-14 bg-gradient-to-br from-gold/15 via-cream to-sage/15 border border-gold/30 grain text-center">
              <div aria-hidden className="absolute -top-24 -right-24 h-72 w-72 rounded-full bg-gold/25 blur-3xl animate-blob" />
              <div aria-hidden className="absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-sage/25 blur-3xl animate-blob" style={{ animationDelay: "3s" }} />
              <h2 className="relative font-display text-3xl md:text-4xl text-primary">
                Prêt à passer à l'action ?
              </h2>
              <p className="relative mt-5 text-ink/75 text-lg max-w-2xl mx-auto leading-relaxed">
                Maquette de votre site offerte en 48h, sans engagement. Si elle ne vous convient pas, vous ne devez rien.
              </p>
              <Link to="/contact" className="relative mt-8 btn-primary inline-flex">
                Obtenir ma maquette gratuite
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}

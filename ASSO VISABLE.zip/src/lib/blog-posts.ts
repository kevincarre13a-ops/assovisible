export interface BlogPostMeta {
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  date: string; // ISO yyyy-mm-dd
  readingTime: string;
  metaTitle: string;
  metaDescription: string;
}

export const blogPosts: BlogPostMeta[] = [
  {
    slug: "creer-site-web-association-loi-1901",
    title: "Comment créer le site web de son association loi 1901 ?",
    excerpt:
      "Toutes les étapes pour lancer un site associatif efficace : objectifs, contenu, choix techniques, budget et accompagnement.",
    category: "Guide pratique",
    date: "2026-06-10",
    readingTime: "8 min",
    metaTitle: "Créer le site web de son association loi 1901 — Guide",
    metaDescription:
      "Découvrez comment créer le site web de votre association loi 1901 : objectifs, contenu, budget et solutions. Demandez votre maquette gratuite en 48h.",
  },
  {
    slug: "pourquoi-association-besoin-site-web",
    title: "Pourquoi votre association a besoin d'un site web en 2026",
    excerpt:
      "Visibilité, crédibilité, dons, recrutement de bénévoles : les vraies raisons d'investir dans un site web pour votre association.",
    category: "Stratégie",
    date: "2026-06-03",
    readingTime: "7 min",
    metaTitle: "Pourquoi votre association a besoin d'un site web en 2026",
    metaDescription:
      "Visibilité, crédibilité, dons, bénévoles : 7 raisons concrètes d'avoir un site web pour son association en 2026. Lancez le vôtre avec AssoVisible.",
  },
  {
    slug: "helloasso-vs-site-web-association",
    title: "HelloAsso vs site web : quelle solution choisir pour son association ?",
    excerpt:
      "Comparatif complet entre une page HelloAsso et un véritable site associatif. Avantages, limites et combinaison gagnante.",
    category: "Comparatif",
    date: "2026-05-22",
    readingTime: "9 min",
    metaTitle: "HelloAsso vs site web : que choisir pour son association ?",
    metaDescription:
      "HelloAsso ou site web : comparatif détaillé pour les associations loi 1901. Découvrez la solution adaptée à votre projet et obtenez votre devis gratuit.",
  },
  {
    slug: "site-web-association-financement",
    title: "Comment financer le site web de son association ?",
    excerpt:
      "Subventions, mécénat, FDVA, dons défiscalisés, autofinancement : 6 pistes concrètes pour financer votre site associatif.",
    category: "Financement",
    date: "2026-05-12",
    readingTime: "8 min",
    metaTitle: "Comment financer le site web de son association ?",
    metaDescription:
      "FDVA, mécénat, subventions, dons : 6 solutions concrètes pour financer le site web de votre association loi 1901. Demandez un devis gratuit en 48h.",
  },
  {
    slug: "augmenter-adherents-association-internet",
    title: "Comment trouver plus d'adhérents grâce à internet ?",
    excerpt:
      "SEO local, réseaux sociaux, formulaire d'adhésion en ligne : les leviers digitaux pour faire grandir votre association.",
    category: "Recrutement",
    date: "2026-05-02",
    readingTime: "8 min",
    metaTitle: "Trouver plus d'adhérents pour son association en ligne",
    metaDescription:
      "SEO local, réseaux sociaux, adhésion en ligne : nos conseils pour recruter plus d'adhérents pour votre association grâce à internet. Lancez votre site.",
  },
  {
    slug: "site-web-association-sportive",
    title: "Site web pour association sportive : tout ce qu'il faut savoir",
    excerpt:
      "Calendrier, résultats, inscriptions, dons : les fonctionnalités indispensables d'un site pour club sportif amateur.",
    category: "Spécialisé",
    date: "2026-04-20",
    readingTime: "8 min",
    metaTitle: "Site web pour association sportive : guide complet",
    metaDescription:
      "Calendrier, résultats, inscriptions en ligne : les fonctionnalités indispensables d'un site pour club sportif. Obtenez votre maquette gratuite en 48h.",
  },
];

export function getPost(slug: string) {
  return blogPosts.find((p) => p.slug === slug);
}

export function formatFrenchDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });
}

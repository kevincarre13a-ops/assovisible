import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const schema = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(255),
  phone: z.string().trim().max(30).optional().or(z.literal("")),
  asso: z.string().trim().min(2).max(150),
  type: z.string().min(1).max(100),
  message: z.string().trim().min(10).max(2000),
  source: z.string().max(100).optional().or(z.literal("")),
});

const escape = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

const FROM = "AssoVisible <contact@assovisible.fr>";

async function sendResend(payload: Record<string, unknown>, apiKey: string) {
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const txt = await res.text();
    console.error("Resend error", res.status, txt);
    throw new Error("Email delivery failed");
  }
  return res.json();
}

export const sendContactEmail = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => schema.parse(input))
  .handler(async ({ data }) => {
    const RESEND_API_KEY =
      process.env.RESEND_API_KEY || process.env.assovisible;
    if (!RESEND_API_KEY) {
      console.error("Contact form misconfiguration: missing email provider API key");
      throw new Error("Email delivery failed");
    }

    // 1) Notification interne
    const notificationHtml = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #1a1a1a;">
        <h2 style="color: #0f172a; border-bottom: 2px solid #d4af37; padding-bottom: 8px;">
          Nouveau message via le site AssoVisible
        </h2>
        <table style="width: 100%; border-collapse: collapse; margin: 16px 0;">
          <tr><td style="padding: 8px 0;"><strong>Nom :</strong></td><td>${escape(data.name)}</td></tr>
          <tr><td style="padding: 8px 0;"><strong>Email :</strong></td><td><a href="mailto:${escape(data.email)}">${escape(data.email)}</a></td></tr>
          <tr><td style="padding: 8px 0;"><strong>Téléphone :</strong></td><td>${escape(data.phone || "—")}</td></tr>
          <tr><td style="padding: 8px 0;"><strong>Association :</strong></td><td>${escape(data.asso)}</td></tr>
          <tr><td style="padding: 8px 0;"><strong>Type :</strong></td><td>${escape(data.type)}</td></tr>
          <tr><td style="padding: 8px 0;"><strong>Source :</strong></td><td>${escape(data.source || "—")}</td></tr>
        </table>
        <h3 style="color: #0f172a; margin-top: 24px;">Message</h3>
        <p style="white-space: pre-wrap; background: #f8f5ee; padding: 16px; border-radius: 8px; line-height: 1.6;">
${escape(data.message)}
        </p>
      </div>
    `;

    await sendResend(
      {
        from: FROM,
        to: ["contact@assovisible.fr"],
        reply_to: data.email,
        subject: `Nouveau message de ${data.name}`,
        html: notificationHtml,
      },
      RESEND_API_KEY,
    );

    // 2) Confirmation à l'utilisateur (non bloquant)
    const firstName = data.name.split(" ")[0];
    const confirmationHtml = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #1a1a1a; line-height: 1.6;">
        <h2 style="color: #0f172a;">Merci ${escape(firstName)} 🙏</h2>
        <p>Nous avons bien reçu votre message et vous remercions de l'intérêt que vous portez à <strong>AssoVisible</strong>.</p>
        <p>Notre équipe va étudier votre demande avec attention et vous recontactera <strong>sous 48 heures ouvrées</strong> par email ou par téléphone pour échanger sur votre projet.</p>
        <div style="background: #f8f5ee; border-left: 4px solid #d4af37; padding: 16px; border-radius: 4px; margin: 24px 0;">
          <p style="margin: 0;"><strong>Récapitulatif de votre message :</strong></p>
          <p style="white-space: pre-wrap; margin: 8px 0 0;">${escape(data.message)}</p>
        </div>
        <p>En attendant, n'hésitez pas à consulter nos <a href="https://assovisible.fr/realisations" style="color: #d4af37;">réalisations</a> pour découvrir nos derniers projets d'associations.</p>
        <p>À très vite,<br/><strong>L'équipe AssoVisible</strong></p>
        <hr style="border: none; border-top: 1px solid #e5e5e5; margin: 24px 0;" />
        <p style="font-size: 12px; color: #888;">
          AssoVisible — Sites web pour associations loi 1901<br/>
          contact@assovisible.fr · <a href="https://assovisible.fr" style="color: #888;">assovisible.fr</a>
        </p>
      </div>
    `;

    try {
      await sendResend(
        {
          from: FROM,
          to: [data.email],
          subject: "Nous avons bien reçu votre message – AssoVisible",
          html: confirmationHtml,
        },
        RESEND_API_KEY,
      );
    } catch (err) {
      // ne bloque pas le flux si la confirmation échoue
      console.error("Confirmation email failed", err);
    }

    return { success: true };
  });

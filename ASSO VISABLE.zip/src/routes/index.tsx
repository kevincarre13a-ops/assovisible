import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Handshake,
  ShieldCheck,
  PhoneCall,
  ClipboardList,
  Palette,
  Rocket,
  GraduationCap,
  Star,
  Check,
  ArrowRight,
  Mail,
  Sparkles,
  Heart,
  TrendingUp,
  Users,
  Zap,
  Globe,
} from "lucide-react";
import { Reveal } from "@/components/Reveal";

import heroImg from "@/assets/hero-community.jpg";
import portfolioCulture from "@/assets/portfolio-culture.jpg";
import portfolioSport from "@/assets/portfolio-sport.jpg";
import portfolioEnv from "@/assets/portfolio-env.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AssoVisible — Site web pour association loi 1901 | Dès 290€" },
      {
        name: "description",
        content:
          "Créez le site de votre association en 5 jours. Site moderne, hébergement français inclus, accompagnement humain. Maquette gratuite en 48h. À partir de 290€.",
      },
      { property: "og:title", content: "AssoVisible — Site web pour association loi 1901 | Dès 290€" },
      {
        property: "og:description",
        content:
          "Créez le site de votre association en 5 jours. Site moderne, hébergement français inclus, accompagnement humain. Maquette gratuite en 48h. À partir de 290€.",
      },
      { name: "twitter:title", content: "AssoVisible — Site web pour association loi 1901 | Dès 290€" },
      {
        name: "twitter:description",
        content:
          "Créez le site de votre association en 5 jours. Site moderne, hébergement français inclus, accompagnement humain. Maquette gratuite en 48h. À partir de 290€.",
      },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden mesh-bg grain">
        {/* Floating blobs */}
        <div aria-hidden className="pointer-events-none absolute inset-0">
          <div className="absolute -top-32 -left-20 h-[420px] w-[420px] rounded-full bg-gold/30 blur-3xl animate-blob" />
          <div className="absolute top-40 -right-32 h-[460px] w-[460px] rounded-full bg-primary/15 blur-3xl animate-blob" style={{ animationDelay: "4s" }} />
          <div className="absolute bottom-0 left-1/3 h-[300px] w-[300px] rounded-full bg-sage/20 blur-3xl animate-blob" style={{ animationDelay: "8s" }} />
        </div>

        <div className="relative container-wide pt-16 pb-24 lg:pt-24 lg:pb-32 grid lg:grid-cols-[1.05fr_1fr] gap-16 items-center">
          <div className="animate-fade-up">
            <span className="chip">
              <Sparkles className="h-3.5 w-3.5" />
              Spécialiste associations loi 1901
            </span>
            <h1 className="mt-7 font-display text-5xl md:text-6xl lg:text-7xl tracking-tight text-primary leading-[1.02]">
              La plateforme web qui rend les{" "}
              <span className="text-gradient-gold">associations</span> visibles.
            </h1>
            <p className="mt-7 text-lg md:text-xl text-ink/70 max-w-xl leading-relaxed">
              Sites professionnels, modernes et humains. Conçus en quelques jours,
              accompagnés à vie. Pour que votre engagement rayonne enfin en ligne.
            </p>
            <div className="mt-10 flex flex-wrap items-center gap-4">
              <Link to="/contact" className="btn-gold group">
                Obtenir ma maquette gratuite
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <Link to="/realisations" className="btn-ghost">
                Voir les réalisations
              </Link>
            </div>

            {/* Mini stats */}
            <div className="mt-12 grid grid-cols-3 gap-6 max-w-md">
              {[
                { v: "127", l: "associations" },
                { v: "4,9/5", l: "satisfaction" },
                { v: "5j", l: "de livraison" },
              ].map((s) => (
                <div key={s.l}>
                  <div className="font-display text-3xl md:text-4xl text-primary font-bold">
                    {s.v}
                  </div>
                  <div className="text-xs text-ink/60 font-sans uppercase tracking-wider mt-1">
                    {s.l}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Visual */}
          <div className="relative animate-fade-up" style={{ animationDelay: "200ms" }}>
            <div className="relative">
              {/* Glow */}
              <div className="absolute -inset-10 bg-gradient-to-tr from-gold/30 via-primary/20 to-sage/30 rounded-[2rem] blur-2xl animate-gradient" />
              {/* Main card */}
              <div className="relative rounded-3xl overflow-hidden border border-white/40 shadow-elegant bg-card">
                <img
                  src={heroImg}
                  alt="Association française moderne en réunion"
                  width={1280}
                  height={960}
                  className="w-full h-auto object-cover aspect-[4/3]"
                />
              </div>

              {/* Floating glass card top-right */}
              <div className="hidden md:flex absolute -top-6 -right-4 lg:-right-10 glass rounded-2xl px-5 py-4 shadow-soft items-center gap-3 animate-float">
                <div className="h-10 w-10 rounded-xl bg-sage/20 flex items-center justify-center">
                  <ShieldCheck className="h-5 w-5 text-sage" />
                </div>
                <div className="font-sans text-sm">
                  <div className="font-semibold text-primary">Hébergement inclus</div>
                  <div className="text-muted-foreground text-xs">Sécurisé en France 🇫🇷</div>
                </div>
              </div>

              {/* Floating glass card bottom-left */}
              <div className="hidden md:flex absolute -bottom-6 -left-4 lg:-left-10 glass rounded-2xl px-5 py-4 shadow-soft items-center gap-3 animate-float-slow" style={{ animationDelay: "1.5s" }}>
                <div className="h-10 w-10 rounded-xl bg-gold/25 flex items-center justify-center">
                  <Zap className="h-5 w-5 text-gold" />
                </div>
                <div className="font-sans text-sm">
                  <div className="font-semibold text-primary">Livré en 5 jours</div>
                  <div className="text-muted-foreground text-xs">Maquette en 48h</div>
                </div>
              </div>

              {/* Rating pill */}
              <div className="absolute top-1/2 -translate-y-1/2 -left-6 lg:-left-12 hidden lg:flex glass rounded-full px-4 py-2 shadow-soft items-center gap-2 animate-float" style={{ animationDelay: "3s" }}>
                <div className="flex gap-0.5 text-gold">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="h-3.5 w-3.5 fill-current" />
                  ))}
                </div>
                <span className="font-sans text-xs font-semibold text-primary">4,9/5</span>
              </div>
            </div>
          </div>
        </div>

        {/* Trust marquee */}
        <div className="relative border-t border-border/60 bg-cream/40 backdrop-blur">
          <div className="container-wide py-6 overflow-hidden">
            <div className="flex gap-12 animate-marquee whitespace-nowrap">
              {[...Array(2)].flatMap((_, k) =>
                [
                  "Spécialiste associations loi 1901",
                  "Hébergement français inclus",
                  "Accompagnement humain dédié",
                  "Devis gratuit sous 24h",
                  "Maquette offerte en 48h",
                  "Paiement en 3× sans frais",
                ].map((l, i) => (
                  <div key={`${k}-${i}`} className="flex items-center gap-2 shrink-0">
                    <Sparkles className="h-4 w-4 text-gold" />
                    <span className="font-sans text-sm font-medium text-primary/80">{l}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </section>

      {/* BENEFITS */}
      <section className="py-28 relative overflow-hidden">
        <div aria-hidden className="absolute top-1/2 left-0 -translate-y-1/2 h-[400px] w-[400px] rounded-full bg-gold/10 blur-3xl" />
        <div className="container-wide relative">
          <Reveal>
            <SectionHeading
              eyebrow="Ce que vous gagnez"
              title="Une présence en ligne qui change tout"
              sub="Plus qu'un site : une plateforme qui amplifie votre impact, votre crédibilité et votre communauté."
            />
          </Reveal>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mt-16">
            {[
              { icon: Globe, title: "Visibilité maximale", text: "Référencé sur Google dès la mise en ligne. Vos actions, partout, tout le temps." , color: "gold" },
              { icon: Heart, title: "Collecte simplifiée", text: "Dons, adhésions, billetterie : intégration HelloAsso et Stripe en quelques clics." , color: "sage" },
              { icon: Users, title: "Communauté engagée", text: "Espace adhérents, newsletter, agenda partagé. Vos bénévoles restent connectés." , color: "primary" },
              { icon: ShieldCheck, title: "Crédibilité immédiate", text: "Un site moderne rassure les financeurs, partenaires et institutions publiques." , color: "gold" },
              { icon: Zap, title: "Autonomie totale", text: "Formation incluse pour modifier vos contenus en autonomie, sans dépendre de personne." , color: "sage" },
              { icon: TrendingUp, title: "Croissance durable", text: "Plus de visites, plus d'adhérents, plus de dons. Mesurable, dès les premiers mois." , color: "primary" },
            ].map((b, i) => (
              <Reveal key={b.title} delay={i * 80}>
                <div className="group relative h-full card-premium p-7 overflow-hidden">
                  <div className={`absolute -top-20 -right-20 h-40 w-40 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 ${
                    b.color === "gold" ? "bg-gold/40" : b.color === "sage" ? "bg-sage/40" : "bg-primary/30"
                  }`} />
                  <div className={`relative h-12 w-12 rounded-xl flex items-center justify-center mb-5 ${
                    b.color === "gold" ? "bg-gold/15 text-gold" :
                    b.color === "sage" ? "bg-sage/15 text-sage" :
                    "bg-primary/10 text-primary"
                  }`}>
                    <b.icon className="h-6 w-6" />
                  </div>
                  <h3 className="relative font-display text-xl mb-2 text-primary">{b.title}</h3>
                  <p className="relative text-ink/70 text-[15px] leading-relaxed">{b.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* PROCESS */}
      <section className="py-28 relative mesh-bg-dark text-cream overflow-hidden">
        <div aria-hidden className="absolute inset-0 grain" />
        <div className="container-wide relative">
          <Reveal>
            <SectionHeading
              eyebrow="Comment ça marche"
              title="De l'idée au lancement, en 4 étapes"
              sub="Un parcours fluide, transparent, sans surprise."
              dark
            />
          </Reveal>
          <div className="mt-20 relative">
            {/* Timeline line */}
            <div aria-hidden className="hidden md:block absolute top-10 left-[12%] right-[12%] h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" />
            <div className="grid md:grid-cols-4 gap-10 relative">
              {[
                { icon: ClipboardList, label: "Échange découverte", note: "30 min, sans engagement" },
                { icon: Palette, label: "Maquette personnalisée", note: "Sous 48h après brief" },
                { icon: Rocket, label: "Mise en ligne", note: "Livraison en 5 jours" },
                { icon: GraduationCap, label: "Formation & suivi", note: "Vous reprenez la main" },
              ].map((s, i) => (
                <Reveal key={s.label} delay={i * 120}>
                  <div className="text-center relative">
                    <div className="relative mx-auto h-20 w-20 rounded-2xl glass-dark flex items-center justify-center group-hover:scale-110 transition shadow-glow">
                      <s.icon className="h-8 w-8 text-gold" />
                      <span className="absolute -top-2 -right-2 h-7 w-7 rounded-full bg-gold text-gold-foreground text-sm font-sans font-bold flex items-center justify-center shadow-lg">
                        {i + 1}
                      </span>
                    </div>
                    <h3 className="font-display text-cream text-xl mt-6">{s.label}</h3>
                    <p className="text-cream/60 text-sm mt-2">{s.note}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* PORTFOLIO PREVIEW */}
      <section className="py-28">
        <div className="container-wide">
          <Reveal>
            <SectionHeading
              eyebrow="Réalisations"
              title="Une communauté d'associations"
              sub="127 sites livrés, du nord au sud de la France. Chaque projet a son identité."
            />
          </Reveal>
          <div className="grid md:grid-cols-3 gap-7 mt-16">
            {[
              { img: portfolioCulture, name: "Les Arts du Quercy", type: "Culturelle", desc: "Site vitrine avec agenda d'événements et galerie photos." },
              { img: portfolioSport, name: "Courir à Bordeaux", type: "Sportive", desc: "Plateforme d'inscription aux courses et espace adhérents." },
              { img: portfolioEnv, name: "Forêts d'Avenir", type: "Environnement", desc: "Site de sensibilisation avec module de dons en ligne." },
            ].map((p, i) => (
              <Reveal key={p.name} delay={i * 100}>
                <article className="group rounded-2xl overflow-hidden card-premium">
                  <div className="aspect-[4/3] overflow-hidden bg-muted relative">
                    <img
                      src={p.img}
                      alt={p.name}
                      loading="lazy"
                      className="w-full h-full object-cover group-hover:scale-110 transition duration-[900ms]"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-primary/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition" />
                    <span className="absolute top-4 left-4 chip !bg-cream/90 !text-primary !border-cream">
                      {p.type}
                    </span>
                  </div>
                  <div className="p-6">
                    <h3 className="font-display text-xl text-primary">{p.name}</h3>
                    <p className="text-ink/65 text-[15px] mt-2 leading-relaxed">{p.desc}</p>
                    <Link
                      to="/realisations"
                      className="inline-flex items-center gap-1.5 mt-5 font-sans text-sm font-semibold text-primary group-hover:text-gold transition"
                    >
                      Voir le projet
                      <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                    </Link>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
          <div className="text-center mt-14">
            <Link to="/realisations" className="btn-ghost">
              Explorer toutes les réalisations
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* TESTIMONIALS + STATS */}
      <section className="py-28 relative overflow-hidden">
        <div aria-hidden className="absolute -top-40 right-0 h-[500px] w-[500px] rounded-full bg-sage/15 blur-3xl" />
        <div aria-hidden className="absolute bottom-0 -left-40 h-[400px] w-[400px] rounded-full bg-gold/15 blur-3xl" />
        <div className="container-wide relative">
          <Reveal>
            <SectionHeading
              eyebrow="Ils parlent de nous"
              title="La parole aux associations"
            />
          </Reveal>

          {/* Stats row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-14 mb-16">
            {[
              { v: "127", l: "Associations accompagnées" },
              { v: "4,9/5", l: "Satisfaction moyenne" },
              { v: "24h", l: "Temps de réponse" },
            ].map((s) => (
              <Reveal key={s.l}>
                <div className="card-premium p-6 text-center">
                  <div className="font-display text-4xl md:text-5xl text-gradient-gold font-bold">
                    {s.v}
                  </div>
                  <div className="mt-2 text-sm text-ink/65 font-sans">{s.l}</div>
                </div>
              </Reveal>
            ))}
          </div>

          <div className="grid md:grid-cols-3 gap-7">
            {[
              { name: "Marie-Christine D.", quote: "J'avais peur que ce soit trop compliqué pour nous. En fait, l'équipe a tout géré et nous a vraiment écoutés. Notre site est magnifique et nos adhérents adorent." },
              { name: "Bernard L.", quote: "Travail sérieux, prix transparent, formation patiente. Nous gérons maintenant notre site nous-mêmes en toute confiance. Je recommande sans hésiter." },
              { name: "Sophie R.", quote: "Notre ancien site datait de 15 ans. AssoVisible a tout repris à zéro avec patience. Nous avons multiplié nos dons en ligne par trois en six mois." },
            ].map((t, i) => (
              <Reveal key={t.name} delay={i * 100}>
                <figure className="h-full card-premium p-7 flex flex-col">
                  <div className="flex gap-1 text-gold" aria-label="5 étoiles sur 5">
                    {Array.from({ length: 5 }).map((_, k) => (
                      <Star key={k} className="h-4 w-4 fill-current" />
                    ))}
                  </div>
                  <blockquote className="mt-5 text-ink/80 leading-relaxed flex-1 text-[16px]">
                    « {t.quote} »
                  </blockquote>
                  <figcaption className="mt-6 pt-5 border-t border-border font-sans">
                    <div className="font-semibold text-primary text-sm">{t.name}</div>
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* OFFRE LANCEMENT */}

      {/* PRICING */}
      <section className="py-28 relative">
        <div className="container-wide">
          <Reveal>
            <SectionHeading
              eyebrow="Tarifs transparents"
              title="Une offre claire, tout compris"
              sub="Un forfait unique pour démarrer, et une option pour rester serein dans le temps."
            />
          </Reveal>

          <div className="grid lg:grid-cols-2 gap-7 mt-16 items-stretch max-w-5xl mx-auto">
            {/* ESSENTIEL — featured */}
            <Reveal>
              <div className="relative h-full">
                <div aria-hidden className="absolute -inset-1 rounded-[1.4rem] bg-gradient-to-br from-gold via-gold/40 to-primary/40 blur-md opacity-70 animate-gradient" />
                <div className="relative h-full rounded-2xl p-8 md:p-10 bg-primary text-cream flex flex-col overflow-hidden">
                  <div aria-hidden className="absolute -top-32 -right-32 h-64 w-64 rounded-full bg-gold/30 blur-3xl" />
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gold text-gold-foreground text-xs font-sans font-bold uppercase tracking-wider px-4 py-1.5 rounded-full shadow-lg">
                    Notre offre phare
                  </span>
                  <h3 className="relative font-display text-3xl text-cream">Essentiel</h3>
                  <div className="relative mt-4 flex items-baseline gap-2">
                    <span className="font-display text-6xl font-bold text-gradient-gold">290€</span>
                    <span className="text-cream/70 font-sans text-sm">tout compris</span>
                  </div>
                  <p className="relative mt-3 text-cream/75 text-[15px]">
                    Paiement en 3× sans frais (3 × 97€) · Livraison en 5 jours
                  </p>
                  <ul className="relative mt-6 space-y-3 flex-1">
                    {[
                      "Site vitrine 5 pages (Accueil, Présentation, Équipe, Contact, Mentions légales)",
                      "Galerie photos (gérée en autonomie via Google Drive)",
                      "Agenda & calendrier événements",
                      "Formulaire de contact",
                      "Carte Google Maps",
                      "Liens réseaux sociaux",
                      "100% adapté mobile & tablette",
                      "Hébergement 1 an inclus",
                    ].map((f) => (
                      <li key={f} className="flex items-start gap-2.5 text-[15px]">
                        <Check className="h-5 w-5 shrink-0 mt-0.5 text-gold" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                  <Link to="/contact" className="relative mt-8 btn-gold w-full">
                    Obtenir ma maquette gratuite
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              </div>
            </Reveal>

            {/* SÉRÉNITÉ */}
            <Reveal delay={120}>
              <div className="h-full card-premium p-8 md:p-10 flex flex-col">
                <span className="chip !bg-sage/15 !text-sage !border-sage/30 w-fit">
                  Option recommandée
                </span>
                <h3 className="font-display text-3xl mt-4 text-primary">Option Sérénité</h3>
                <div className="mt-4 flex items-baseline gap-2">
                  <span className="font-display text-6xl font-bold text-primary">29€</span>
                  <span className="text-muted-foreground font-sans">/mois</span>
                </div>
                <p className="mt-3 text-ink/65 text-[15px]">
                  Pour ne plus jamais avoir à vous soucier de votre site.
                </p>
                <ul className="mt-6 space-y-3 flex-1">
                  {[
                    "Modifications textes & design illimitées",
                    "Ajout de nouvelles pages",
                    "Support par téléphone & email",
                    "Modifications sous 48h ouvrées",
                    "Hébergement & sécurité inclus",
                  ].map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-[15px]">
                      <Check className="h-5 w-5 shrink-0 mt-0.5 text-sage" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <Link to="/contact" className="mt-8 btn-primary w-full">
                  Ajouter l'option Sérénité
                </Link>
              </div>
            </Reveal>
          </div>

          <p className="mt-6 text-center text-xs text-ink/60 font-sans max-w-2xl mx-auto">
            L'offre Essentielle à 290€ est un paiement unique, sans abonnement. L'option Sérénité est facultative.
          </p>

          {/* À LA CARTE */}
          <div className="mt-20 max-w-3xl mx-auto">
            <Reveal>
              <SectionHeading
                eyebrow="Sans abonnement"
                title="Interventions à la carte"
                sub="Vous préférez payer à l'acte ? Voici nos tarifs pour les interventions ponctuelles."
              />
            </Reveal>
            <Reveal>
              <div className="mt-10 rounded-2xl card-premium overflow-hidden">
                <table className="w-full font-sans">
                  <tbody>
                    {[
                      ["Ajout / modification de texte", "25€"],
                      ["Modification design (couleurs, mise en page)", "45€"],
                      ["Ajout d'une nouvelle page", "80€"],
                    ].map(([label, price]) => (
                      <tr key={label} className="border-b border-border last:border-0 hover:bg-secondary/40 transition">
                        <td className="px-6 py-5 text-ink/85">{label}</td>
                        <td className="px-6 py-5 text-right font-display text-2xl text-primary font-bold">
                          {price}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="text-center mt-6 text-[15px] text-ink/70 italic">
                💡 L'option Sérénité à 29€/mois est rentable dès 2 interventions dans le mois.
              </p>
            </Reveal>
          </div>

        </div>
      </section>

      {/* AFFICHES & FLYERS */}
      <section className="py-28 relative bg-cream/40">
        <div className="container-wide">
          <Reveal>
            <SectionHeading
              eyebrow="Affiches & flyers pour vos événements"
              title="Vos visuels d'événements, prêts en 48h"
              sub="Affiche d'assemblée générale, flyer de recrutement bénévoles, visuel pour votre prochaine collecte… on s'occupe de tout, dans le même esprit que votre site."
            />
          </Reveal>

          <div className="grid md:grid-cols-3 gap-7 mt-16 items-stretch max-w-5xl mx-auto">
            {/* Visuel seul */}
            <Reveal>
              <div className="h-full card-premium p-8 flex flex-col">
                <h3 className="font-display text-2xl text-primary">Visuel seul</h3>
                <div className="mt-4 flex items-baseline gap-2">
                  <span className="font-display text-5xl font-bold text-primary">29€</span>
                </div>
                <ul className="mt-6 space-y-3 flex-1">
                  {[
                    "Une affiche OU un flyer",
                    "Fichier prêt à imprimer",
                    "Livré sous 48h",
                  ].map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-[15px]">
                      <Check className="h-5 w-5 shrink-0 mt-0.5 text-sage" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <Link to="/contact" className="mt-8 btn-ghost w-full">
                  Demander mon visuel
                </Link>
              </div>
            </Reveal>

            {/* Pack complet — featured */}
            <Reveal delay={100}>
              <div className="relative h-full">
                <div aria-hidden className="absolute -inset-1 rounded-[1.4rem] bg-gradient-to-br from-gold via-gold/40 to-primary/40 blur-md opacity-70 animate-gradient" />
                <div className="relative h-full rounded-2xl p-8 bg-primary text-cream flex flex-col overflow-hidden">
                  <div aria-hidden className="absolute -top-32 -right-32 h-64 w-64 rounded-full bg-gold/30 blur-3xl" />
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gold text-gold-foreground text-xs font-sans font-bold uppercase tracking-wider px-4 py-1.5 rounded-full shadow-lg whitespace-nowrap">
                    Le plus choisi
                  </span>
                  <h3 className="relative font-display text-2xl text-cream">Pack complet</h3>
                  <div className="relative mt-4 flex items-baseline gap-2">
                    <span className="font-display text-5xl font-bold text-gradient-gold">49€</span>
                  </div>
                  <ul className="relative mt-6 space-y-3 flex-1">
                    {[
                      "Affiche + flyer + visuel réseaux sociaux assortis",
                      "Même univers graphique, cohérent avec votre identité",
                      "Livré sous 48h",
                    ].map((f) => (
                      <li key={f} className="flex items-start gap-2.5 text-[15px]">
                        <Check className="h-5 w-5 shrink-0 mt-0.5 text-gold" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                  <Link to="/contact" className="relative mt-8 btn-gold w-full">
                    Demander mon visuel
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              </div>
            </Reveal>

            {/* Design + impression livrée */}
            <Reveal delay={200}>
              <div className="h-full card-premium p-8 flex flex-col">
                <h3 className="font-display text-2xl text-primary">Design + impression livrée</h3>
                <div className="mt-4 flex items-baseline gap-2">
                  <span className="font-display text-5xl font-bold text-primary">59€</span>
                  <span className="text-muted-foreground font-sans text-sm">à partir de</span>
                </div>
                <ul className="mt-6 space-y-3 flex-1">
                  {[
                    "Pack complet inclus",
                    "Impression et livraison directe chez vous",
                    "Quantité adaptée à votre événement",
                  ].map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-[15px]">
                      <Check className="h-5 w-5 shrink-0 mt-0.5 text-sage" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <Link to="/contact" className="mt-8 btn-ghost w-full">
                  Demander mon visuel
                </Link>
              </div>
            </Reveal>
          </div>

          <p className="text-center mt-10 text-[15px] text-ink/70 italic max-w-2xl mx-auto">
            Vous avez déjà un site avec nous ? On garde le même univers visuel pour vos prochains événements.
          </p>

          <div className="text-center mt-8">
            <Link to="/contact" className="btn-gold">
              Demander mon visuel
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* NEWSLETTER / FINAL CTA */}
      <section className="py-24">
        <div className="container-wide">
          <div className="relative rounded-3xl overflow-hidden mesh-bg-dark text-cream p-10 md:p-16 grid lg:grid-cols-2 gap-10 items-center grain">
            <div aria-hidden className="absolute top-0 right-0 h-80 w-80 rounded-full bg-gold/20 blur-3xl animate-blob" />
            <div aria-hidden className="absolute bottom-0 left-0 h-80 w-80 rounded-full bg-sage/20 blur-3xl animate-blob" style={{ animationDelay: "5s" }} />
            <div className="relative">
              <span className="chip !bg-gold/20 !text-gold !border-gold/40">
                <Sparkles className="h-3.5 w-3.5" /> Guide gratuit
              </span>
              <h2 className="font-display text-3xl md:text-5xl text-cream mt-5 leading-tight">
                10 questions à poser avant de créer le site de votre association
              </h2>
              <p className="text-cream/75 mt-5 text-[17px] max-w-lg">
                Reçu par plus de 2 000 dirigeants associatifs. Conçu par notre équipe,
                gratuit et sans spam.
              </p>
            </div>
            <form
              className="relative flex flex-col sm:flex-row gap-3"
              onSubmit={(e) => {
                e.preventDefault();
                window.location.href = "/guide";
              }}
            >
              <div className="relative flex-1">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <input
                  type="email"
                  placeholder="votre@email.fr"
                  className="w-full bg-cream text-ink rounded-xl pl-12 pr-4 py-4 font-sans placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-gold"
                />
              </div>
              <button type="submit" className="btn-gold">
                Accéder au guide gratuit →
              </button>
            </form>
          </div>
        </div>
      </section>
    </>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  sub,
  dark = false,
}: {
  eyebrow: string;
  title: string;
  sub?: string;
  dark?: boolean;
}) {
  return (
    <div className="max-w-2xl mx-auto text-center">
      <span className={`eyebrow ${dark ? "!text-gold" : ""}`}>{eyebrow}</span>
      <h2 className={`mt-5 font-display text-4xl md:text-5xl lg:text-[3.5rem] tracking-tight ${dark ? "!text-cream" : ""}`}>
        {title}
      </h2>
      {sub && (
        <p className={`mt-5 text-lg ${dark ? "text-cream/70" : "text-ink/65"}`}>{sub}</p>
      )}
    </div>
  );
}

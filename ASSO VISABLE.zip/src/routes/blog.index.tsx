import { createFileRoute, Link } from "@tanstack/react-router";
import { Sparkles, Calendar, Clock, ArrowRight } from "lucide-react";
import { Reveal } from "@/components/Reveal";
import { blogPosts, formatFrenchDate } from "@/lib/blog-posts";

export const Route = createFileRoute("/blog/")({
  head: () => ({
    meta: [
      { title: "Blog AssoVisible — conseils web pour associations loi 1901" },
      {
        name: "description",
        content:
          "Conseils, guides et comparatifs pour créer, financer et faire grandir le site web de votre association loi 1901. Lisez nos articles experts.",
      },
      { property: "og:title", content: "Blog AssoVisible — conseils web pour associations loi 1901" },
      {
        property: "og:description",
        content:
          "Conseils, guides et comparatifs pour créer, financer et faire grandir le site web de votre association loi 1901. Lisez nos articles experts.",
      },
      { property: "og:url", content: "https://assovisible.fr/blog" },
    ],
    links: [{ rel: "canonical", href: "https://assovisible.fr/blog" }],
  }),
  component: BlogIndexPage,
});

function BlogIndexPage() {
  const posts = [...blogPosts].sort((a, b) => (a.date < b.date ? 1 : -1));
  return (
    <>
      <section className="relative py-24 mesh-bg grain overflow-hidden">
        <div aria-hidden className="absolute -top-20 right-1/4 h-72 w-72 rounded-full bg-sage/25 blur-3xl animate-blob" />
        <div aria-hidden className="absolute bottom-0 left-1/4 h-80 w-80 rounded-full bg-gold/20 blur-3xl animate-blob" style={{ animationDelay: "4s" }} />
        <div className="container-wide relative text-center max-w-3xl mx-auto">
          <span className="chip"><Sparkles className="h-3.5 w-3.5" /> Le blog</span>
          <h1 className="mt-6 font-display text-5xl md:text-6xl tracking-tight">
            Conseils web pour <span className="text-gradient-gold">associations</span>
          </h1>
          <p className="mt-6 text-lg text-ink/70 leading-relaxed">
            Guides, comparatifs et retours d'expérience pour aider votre association loi 1901 à
            réussir son site web, sa communication et son recrutement de bénévoles.
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="container-wide max-w-5xl">
          <div className="grid gap-8 md:grid-cols-2">
            {posts.map((p, i) => (
              <Reveal key={p.slug} delay={i * 60}>
                <Link
                  to="/blog/$slug"
                  params={{ slug: p.slug }}
                  className="group card-premium p-7 flex flex-col h-full hover:-translate-y-1 transition-transform"
                >
                  <p className="text-xs font-sans font-bold tracking-wider text-sage">
                    {p.category.toUpperCase()}
                  </p>
                  <h2 className="mt-3 font-display text-2xl text-primary leading-snug group-hover:text-gold transition-colors">
                    {p.title}
                  </h2>
                  <p className="mt-4 text-ink/70 text-[15px] leading-relaxed flex-1">
                    {p.excerpt}
                  </p>
                  <div className="mt-6 flex items-center justify-between text-xs font-sans text-ink/55 border-t border-border pt-4">
                    <span className="inline-flex items-center gap-1.5">
                      <Calendar className="h-3.5 w-3.5" /> {formatFrenchDate(p.date)}
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <Clock className="h-3.5 w-3.5" /> {p.readingTime}
                    </span>
                  </div>
                  <span className="mt-5 inline-flex items-center gap-1.5 text-sm font-sans font-semibold text-primary group-hover:text-gold transition-colors">
                    Lire l'article <ArrowRight className="h-4 w-4" />
                  </span>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container-wide max-w-4xl">
          <div className="relative rounded-3xl overflow-hidden mesh-bg-dark text-cream p-12 md:p-14 text-center grain">
            <div aria-hidden className="absolute -top-20 -left-20 h-72 w-72 rounded-full bg-gold/25 blur-3xl animate-blob" />
            <div aria-hidden className="absolute -bottom-20 -right-20 h-72 w-72 rounded-full bg-sage/20 blur-3xl animate-blob" style={{ animationDelay: "5s" }} />
            <h2 className="relative font-display text-cream text-3xl md:text-4xl">
              Un projet de site associatif ?
            </h2>
            <p className="relative mt-4 text-cream/75 text-lg">
              Maquette offerte en 48h, sans engagement. Réponse sous 24h.
            </p>
            <Link to="/contact" className="relative mt-8 btn-gold inline-flex">
              Obtenir ma maquette gratuite
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}

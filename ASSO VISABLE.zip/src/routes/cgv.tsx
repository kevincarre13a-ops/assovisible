import { createFileRoute, Link } from "@tanstack/react-router";
import { Reveal } from "@/components/Reveal";
import { ScrollText, FileText, ShieldCheck, CreditCard, Truck, UserCheck, RotateCcw, Ban, AlertTriangle, BrainCircuit, Lock, CloudLightning, Scale, Mail, ChevronRight, CalendarDays } from "lucide-react";

export const Route = createFileRoute("/cgv")({
  head: () => ({
    meta: [
      { title: "Conditions Générales de Vente (CGV) | AssoVisible" },
      { name: "description", content: "Conditions Générales de Vente AssoVisible : commande, tarifs, livraison, paiement et garanties pour la création de sites web associatifs. Consultez-les ici." },
      { property: "og:title", content: "Conditions Générales de Vente (CGV) | AssoVisible" },
      { property: "og:description", content: "Conditions Générales de Vente AssoVisible : commande, tarifs, livraison, paiement et garanties pour la création de sites web associatifs. Consultez-les ici." },
    ],
  }),
  component: CgvPage,
});

const sections = [
  {
    id: "objet",
    icon: FileText,
    title: "1. Objet",
    content: (
      <>
        <p>Les présentes Conditions Générales de Vente (ci-après « CGV ») ont pour objet de définir les droits et obligations des parties dans le cadre de la fourniture de prestations de services numériques par AssoVisible (ci-après « le Prestataire ») à ses clients (ci-après « le Client »), personnes physiques ou morales agissant à des fins non professionnelles ou associations loi 1901.</p>
        <p className="mt-4">Elles s'appliquent à l'exclusion de toutes autres conditions, et notamment celles applicables pour les ventes sur internet. Les CGV sont accessibles à tout moment sur le site assovisible.fr et prévaudront, le cas échéant, sur toute autre version ou tout autre document contradictoire.</p>
        <p className="mt-4">Le fait pour le Client de commander une prestation implique l'adhésion entière et sans réserve aux présentes CGV.</p>
      </>
    ),
  },
  {
    id: "identification",
    icon: ShieldCheck,
    title: "2. Identification de l'entreprise",
    content: (
      <>
        <ul className="space-y-2 list-disc pl-5">
          <li><strong>Nom commercial :</strong> AssoVisible</li>
          <li><strong>Statut juridique :</strong> Micro-entreprise</li>
          <li><strong>Siège social :</strong> Aix-en-Provence, France</li>
          <li><strong>Email :</strong> <a href="mailto:contact@assovisible.fr" className="text-gold hover:underline">contact@assovisible.fr</a></li>
          <li><strong>Site web :</strong> <a href="https://assovisible.fr" className="text-gold hover:underline">assovisible.fr</a></li>
          <li><strong>Numéro de TVA intracommunautaire :</strong> Non applicable (franchise en base de TVA — art. 293 B du CGI)</li>
        </ul>
      </>
    ),
  },
  {
    id: "services",
    icon: ScrollText,
    title: "3. Services proposés",
    content: (
      <>
        <p>AssoVisible propose des prestations de services numériques à destination des associations et organisations, notamment :</p>
        <ul className="space-y-2 list-disc pl-5 mt-4">
          <li>Conception et création de sites internet vitrines et événementiels</li>
          <li>Référencement naturel (SEO) et conseil en visibilité en ligne</li>
          <li>Accompagnement digital et formation à l'autonomie</li>
          <li>Conception d'affiches, flyers et visuels pour réseaux sociaux</li>
          <li>Maintenance technique, sauvegardes et mises à jour de sécurité</li>
          <li>Prestations connexes et sur mesure sur devis</li>
        </ul>
        <p className="mt-4">Les caractéristiques essentielles des services sont présentées sur le site assovisible.fr. Le Client est tenu d'en prendre connaissance avant toute commande.</p>
      </>
    ),
  },
  {
    id: "commande",
    icon: FileText,
    title: "4. Commande et validation",
    content: (
      <>
        <p>La commande est validée par le Client après acceptation d'un devis personnalisé ou d'un bon de commande, transmis par email par le Prestataire. Le devis détaille la nature des prestations, les tarifs applicables, les délais estimés et les conditions particulières éventuelles.</p>
        <p className="mt-4">La validation du devis par le Client (retour signé, email de confirmation ou paiement de l'acompte) vaut conclusion du contrat et acceptation pleine et entière des présentes CGV.</p>
        <p className="mt-4">AssoVisible se réserve le droit de refuser une commande en cas de litige antérieur avec le Client, d'incohérence des informations fournies, ou pour tout autre motif légitime.</p>
      </>
    ),
  },
  {
    id: "tarifs",
    icon: Scale,
    title: "5. Tarifs",
    content: (
      <>
        <p>Les prix des prestations sont indiqués en euros (€), toutes taxes comprises (TTC), sous réserve de la franchise en base de TVA applicable aux micro-entreprises. Les tarifs en vigueur sont ceux affichés sur le site ou mentionnés dans le devis personnalisé au jour de la commande.</p>
        <p className="mt-4">AssoVisible se réserve le droit de modifier ses tarifs à tout moment. Toutefois, les prestations commandées sont facturées au prix en vigueur au moment de la validation du devis par le Client.</p>
        <p className="mt-4">Toute demande de prestation supplémentaire, non prévue dans le devis initial, fera l'objet d'un devis complémentaire soumis à l'accord préalable du Client.</p>
      </>
    ),
  },
  {
    id: "paiement",
    icon: CreditCard,
    title: "6. Modalités de paiement",
    content: (
      <>
        <p>Le règlement des prestations s'effectue selon les modalités suivantes :</p>
        <ul className="space-y-2 list-disc pl-5 mt-4">
          <li><strong>Carte bancaire</strong> via la plateforme sécurisée Stripe</li>
          <li><strong>Virement bancaire</strong> sur demande</li>
        </ul>
        <p className="mt-4">Pour les prestations de création de site web, un acompte de 30 % est exigé à la commande. Le solde est payable à la livraison finale du site, avant mise en ligne. Pour les forfaits de maintenance ou autres services récurrents, le paiement s'effectue selon la périodicité convenue (mensuelle ou annuelle).</p>
        <p className="mt-4">En cas de retard de paiement, des pénalités de retard équivalentes à trois fois le taux d'intérêt légal seront appliquées, sans qu'un rappel soit nécessaire, conformément aux articles L. 441-6 et D. 441-5 du Code de commerce. Une indemnité forfaitaire de 40 € pour frais de recouvrement pourra également être réclamée.</p>
      </>
    ),
  },
  {
    id: "execution",
    icon: Truck,
    title: "7. Exécution et livraison des prestations",
    content: (
      <>
        <p>Les délais de réalisation sont indicatifs et communiqués à titre estimatif dans le devis. La durée moyenne de création d'un site vitrine est de 4 à 6 semaines à compter de la réception de l'ensemble des contenus et validations nécessaires de la part du Client.</p>
        <p className="mt-4">La prestation est considérée comme livrée lorsque le site web ou le service commandé est finalisé et mis à disposition du Client (mise en ligne, livraison des fichiers, ou transfert des accès). Une phase de recette de 7 jours est prévue pour permettre au Client de signaler d'éventuelles corrections mineures.</p>
        <p className="mt-4">Le Client s'engage à fournir dans les délais convenus l'ensemble des éléments nécessaires à la réalisation de la prestation (textes, images, logos, charte graphique, accès, etc.). Tout retard dans la fourniture de ces éléments pourra entraîner un report des délais de livraison sans que la responsabilité d'AssoVisible ne puisse être engagée.</p>
      </>
    ),
  },
  {
    id: "obligations-client",
    icon: UserCheck,
    title: "8. Obligations du client",
    content: (
      <>
        <p>Le Client s'engage à :</p>
        <ul className="space-y-2 list-disc pl-5 mt-4">
          <li>Fournir des informations exactes, complètes et à jour lors de la commande</li>
          <li>Remettre les contenus (textes, images, documents) dans les formats et délais convenus</li>
          <li>Détenir les droits nécessaires sur les éléments fournis (droits d'auteur, droit à l'image, etc.)</li>
          <li>Valider les étapes de réalisation dans un délai raisonnable (7 jours ouvrés par étape)</li>
          <li>Régler les sommes dues aux échéances convenues</li>
          <li>Respecter la législation en vigueur dans l'utilisation du service livré</li>
        </ul>
        <p className="mt-4">Le Client est seul responsable du contenu éditorial publié sur son site. AssoVisible ne saurait être tenu pour responsable en cas de contenu illicite, diffamatoire ou portant atteinte aux droits de tiers.</p>
      </>
    ),
  },
  {
    id: "retractation",
    icon: RotateCcw,
    title: "9. Droit de rétractation",
    content: (
      <>
        <p>Conformément aux articles L. 221-18 et suivants du Code de la consommation, le Client dispose d'un délai de 14 jours calendaires à compter de la conclusion du contrat pour exercer son droit de rétractation, sans avoir à justifier de motifs ni à payer de pénalités.</p>
        <p className="mt-4"><strong>Toutefois,</strong> en application de l'article L. 221-28 du Code de la consommation, le droit de rétractation ne peut être exercé pour les prestations de services numériques lorsque leur exécution a commencé, avec l'accord exprès du Client, avant la fin du délai de rétractation. En validant la commande, le Client accepte expressément que la prestation débute immédiatement et renonce expressément à son droit de rétractation.</p>
      </>
    ),
  },
  {
    id: "annulation",
    icon: Ban,
    title: "10. Politique d'annulation et de remboursement",
    content: (
      <>
        <p><strong>Avant le début de la prestation :</strong> En cas d'annulation par le Client avant le début effectif des travaux, l'acompte versé sera remboursé intégralement sous 14 jours, déduction faite des frais bancaires éventuels.</p>
        <p className="mt-4"><strong>Après le début de la prestation :</strong> Aucun remboursement n'est possible après validation de la commande et démarrage des travaux, sauf obligation légale contraire ou accord express entre les parties. Le Client reste redevable des prestations déjà réalisées et des frais engagés.</p>
        <p className="mt-4"><strong>Annulation par le Prestataire :</strong> Si AssoVisible est contraint d'annuler une prestation pour des raisons indépendantes de sa volonté, l'ensemble des sommes versées par le Client lui sera remboursé sans délai.</p>
      </>
    ),
  },
  {
    id: "responsabilite",
    icon: AlertTriangle,
    title: "11. Responsabilité",
    content: (
      <>
        <p>AssoVisible s'engage à mettre en œuvre tous les moyens nécessaires pour assurer la qualité de ses prestations. Toutefois, sa responsabilité ne pourra être engagée qu'en cas de faute prouvée et sera limitée au montant de la prestation concernée.</p>
        <p className="mt-4">AssoVisible ne pourra être tenu responsable :</p>
        <ul className="space-y-2 list-disc pl-5 mt-4">
          <li>Des dommages indirects, pertes d'exploitation, pertes de données ou manque à gagner</li>
          <li>De l'indisponibilité temporaire du site liée à des opérations de maintenance, des attaques informatiques ou des défaillances de l'hébergeur</li>
          <li>Des contenus publiés par le Client en violation des droits de tiers</li>
          <li>De l'utilisation frauduleuse ou illicite du service par le Client ou des tiers</li>
        </ul>
        <p className="mt-4">AssoVisible s'engage à souscrire et maintenir une assurance de responsabilité civile professionnelle auprès d'une compagnie d'assurance solvente.</p>
      </>
    ),
  },
  {
    id: "propriete-intellectuelle",
    icon: BrainCircuit,
    title: "12. Propriété intellectuelle",
    content: (
      <>
        <p><strong>Créations du Prestataire :</strong> Les créations réalisées par AssoVisible (maquettes, codes, graphismes, visuels) restent la propriété exclusive d'AssoVisible jusqu'au paiement intégral du prix convenu. À compter du règlement total, les droits d'usage sont transférés au Client pour une exploitation exclusive sur le site livré. Le Client ne peut en revendiquer la propriété intellectuelle ni les réutiliser pour créer un service concurrent.</p>
        <p className="mt-4"><strong>Éléments fournis par le Client :</strong> Le Client garantit détenir tous les droits sur les contenus qu'il fournit (textes, images, logos, vidéos, etc.) et autorise AssoVisible à les utiliser et reproduire dans le cadre de la prestation commandée.</p>
        <p className="mt-4"><strong>Outils et frameworks :</strong> AssoVisible utilise des outils, frameworks et bibliothèques open source dont les licences respectives s'appliquent. Ces éléments ne sont pas la propriété d'AssoVisible ni du Client, mais sont utilisés conformément à leurs licences respectives.</p>
      </>
    ),
  },
  {
    id: "donnees-personnelles",
    icon: Lock,
    title: "13. Protection des données personnelles",
    content: (
      <>
        <p>AssoVisible collecte et traite les données personnelles du Client conformément au Règlement Général sur la Protection des Données (RGPD — règlement UE 2016/679) et à la loi Informatique et Libertés modifiée.</p>
        <p className="mt-4">Les données collectées (nom, email, téléphone, nom de l'association) sont nécessaires à la gestion de la commande, à la facturation et à la relation client. Elles ne sont pas cédées à des tiers sans consentement préalable.</p>
        <p className="mt-4">Conformément à la réglementation, le Client dispose d'un droit d'accès, de rectification, d'effacement, de limitation du traitement et de portabilité de ses données. Pour exercer ces droits, le Client peut contacter AssoVisible à l'adresse <a href="mailto:contact@assovisible.fr" className="text-gold hover:underline">contact@assovisible.fr</a>.</p>
        <p className="mt-4">Le site assovisible.fr utilise des cookies techniques nécessaires au fonctionnement du site. Aucun cookie publicitaire ou de traçage tiers n'est déposé sans consentement préalable.</p>
      </>
    ),
  },
  {
    id: "force-majeure",
    icon: CloudLightning,
    title: "14. Force majeure",
    content: (
      <>
        <p>Les parties ne seront pas tenues pour responsables de tout retard ou manquement à leurs obligations résultant d'un cas de force majeure tel que défini par l'article 1218 du Code civil et la jurisprudence française, notamment : grèves, inondations, incendies, interruptions de service des fournisseurs d'hébergement, attaques informatiques de grande ampleur, pandémie, ou toute autre circonstance indépendante de la volonté des parties.</p>
        <p className="mt-4">En cas de survenance d'un événement de force majeure, la partie affectée en informera l'autre partie dans les plus brefs délais. Les obligations des parties seront suspendues pendant toute la durée de l'événement. Si la force majeure se prolonge au-delà de 60 jours, chaque partie pourra résilier le contrat sans indemnité.</p>
      </>
    ),
  },
  {
    id: "droit-applicable",
    icon: Scale,
    title: "15. Droit applicable et règlement des litiges",
    content: (
      <>
        <p>Les présentes CGV sont soumises au droit français. En cas de litige, les parties s'engagent à rechercher préalablement une solution amiable. À défaut d'accord amiable dans un délai de 60 jours à compter de la notification du litige, le tribunal compétent sera celui du lieu du siège social d'AssoVisible, sauf disposition légale impérative contraire.</p>
        <p className="mt-4">Conformément aux dispositions du Code de la consommation relatives au règlement amiable des litiges, le Client peut recourir gratuitement au médiateur de la consommation dont relève AssoVisible. À défaut, tout litige relèvera de la compétence des juridictions françaises compétentes.</p>
      </>
    ),
  },
  {
    id: "contact",
    icon: Mail,
    title: "16. Contact",
    content: (
      <>
        <p>Pour toute question relative aux présentes Conditions Générales de Vente, vous pouvez contacter AssoVisible :</p>
        <ul className="space-y-2 list-disc pl-5 mt-4">
          <li><strong>Email :</strong> <a href="mailto:contact@assovisible.fr" className="text-gold hover:underline">contact@assovisible.fr</a></li>
          <li><strong>Téléphone :</strong> <a href="tel:+33647474581" className="text-gold hover:underline">06 47 47 45 81</a></li>
          <li><strong>Adresse :</strong> Aix-en-Provence, France</li>
          <li><strong>Site web :</strong> <a href="https://assovisible.fr" className="text-gold hover:underline">assovisible.fr</a></li>
        </ul>
        <p className="mt-4">Nous nous efforçons de répondre à toute demande dans un délai de 24 à 48 heures ouvrées.</p>
      </>
    ),
  },
];

function CgvPage() {
  return (
    <>
      {/* HERO */}
      <section className="relative py-20 md:py-28 mesh-bg grain overflow-hidden">
        <div aria-hidden className="absolute -top-20 right-1/4 h-72 w-72 rounded-full bg-gold/20 blur-3xl animate-blob" />
        <div aria-hidden className="absolute bottom-0 left-1/4 h-80 w-80 rounded-full bg-sage/15 blur-3xl animate-blob" style={{ animationDelay: "4s" }} />
        <div className="container-wide relative text-center max-w-3xl mx-auto">
          <span className="chip"><ScrollText className="h-3.5 w-3.5" /> Documents légaux</span>
          <h1 className="mt-6 font-display text-4xl md:text-5xl lg:text-6xl tracking-tight">
            Conditions Générales de <span className="text-gradient-gold">Vente</span>
          </h1>
          <p className="mt-5 text-lg md:text-xl text-ink/65 leading-relaxed">
            Les règles qui encadrent nos collaborations. Transparentes, justes et conformes au droit français.
          </p>
          <div className="mt-6 inline-flex items-center gap-2 text-sm text-muted-foreground font-sans">
            <CalendarDays className="h-4 w-4" />
            Dernière mise à jour : 18 juin 2026
          </div>
        </div>
      </section>

      {/* TABLE DES MATIÈRES */}
      <section className="py-10 bg-secondary/30">
        <div className="container-prose max-w-4xl">
          <Reveal>
            <div className="bg-card border border-border rounded-xl p-6 md:p-8">
              <h2 className="font-display text-xl mb-4">Sommaire</h2>
              <nav className="grid sm:grid-cols-2 gap-2">
                {sections.map((s) => (
                  <a
                    key={s.id}
                    href={`#${s.id}`}
                    className="flex items-center gap-2 py-1.5 px-3 rounded-md text-sm text-ink/80 hover:bg-primary/5 hover:text-primary transition-colors"
                  >
                    <ChevronRight className="h-3.5 w-3.5 text-gold shrink-0" />
                    {s.title}
                  </a>
                ))}
              </nav>
            </div>
          </Reveal>
        </div>
      </section>

      {/* CONTENT */}
      <section className="py-16 md:py-24">
        <div className="container-prose max-w-3xl space-y-16">
          {sections.map((s, i) => {
            const Icon = s.icon;
            return (
              <Reveal key={s.id} delay={i % 3 === 0 ? 0 : i % 3 === 1 ? 40 : 80}>
                <article id={s.id} className="scroll-mt-28">
                  <div className="flex items-start gap-4 mb-5">
                    <div className="hidden sm:flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gold/10 text-gold">
                      <Icon className="h-5 w-5" />
                    </div>
                    <h2 className="font-display text-2xl md:text-3xl pt-0.5">{s.title}</h2>
                  </div>
                  <div className="prose prose-lg max-w-none text-ink/80 leading-relaxed font-serif">
                    {s.content}
                  </div>
                  {i < sections.length - 1 && (
                    <div className="mt-10 border-b border-border" />
                  )}
                </article>
              </Reveal>
            );
          })}
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-primary text-cream relative overflow-hidden grain">
        <div aria-hidden className="absolute -top-20 -right-20 h-72 w-72 rounded-full bg-gold/15 blur-3xl animate-blob" />
        <div aria-hidden className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full bg-sage/15 blur-3xl animate-blob" style={{ animationDelay: "5s" }} />
        <div className="container-wide relative text-center max-w-2xl mx-auto">
          <h2 className="font-display text-3xl md:text-4xl">Une question sur nos CGV ?</h2>
          <p className="mt-4 text-cream/75 text-lg">
            Nous sommes là pour éclaircir tout point. L'échange reste gratuit et sans engagement.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/contact" className="btn-gold">
              Nous contacter
            </Link>
            <a href="mailto:contact@assovisible.fr" className="btn-ghost !text-cream !border-cream/20 hover:!bg-cream/10">
              <Mail className="h-4 w-4" /> contact@assovisible.fr
            </a>
          </div>
        </div>
      </section>
    </>
  );
}

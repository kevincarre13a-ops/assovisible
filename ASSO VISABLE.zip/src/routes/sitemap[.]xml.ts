import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";
import { blogPosts } from "@/lib/blog-posts";



const BASE_URL = "https://assovisible.fr";

interface SitemapEntry {
  path: string;
  lastmod?: string;
  changefreq?: "always" | "hourly" | "daily" | "weekly" | "monthly" | "yearly" | "never";
  priority?: string;
}

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const lastmod = new Date().toISOString().split("T")[0];
        const entries: SitemapEntry[] = [
          { path: "/", lastmod, changefreq: "weekly", priority: "1.0" },
          { path: "/services", lastmod, changefreq: "monthly", priority: "0.8" },
          { path: "/realisations", lastmod, changefreq: "monthly", priority: "0.8" },
          { path: "/a-propos", lastmod, changefreq: "monthly", priority: "0.8" },
          { path: "/guide", lastmod, changefreq: "monthly", priority: "0.8" },
          { path: "/blog", lastmod, changefreq: "weekly", priority: "0.8" },
          { path: "/contact", lastmod, changefreq: "monthly", priority: "0.8" },
          ...blogPosts.map((p) => ({
            path: `/blog/${p.slug}`,
            lastmod: p.date,
            changefreq: "monthly" as const,
            priority: "0.7",
          })),
          { path: "/mentions-legales", lastmod, changefreq: "yearly", priority: "0.3" },
          { path: "/confidentialite", lastmod, changefreq: "yearly", priority: "0.3" },
          { path: "/cgv", lastmod, changefreq: "yearly", priority: "0.3" },
        ];


        const urls = entries.map((e) =>
          [
            `  <url>`,
            `    <loc>${BASE_URL}${e.path}</loc>`,
            e.lastmod ? `    <lastmod>${e.lastmod}</lastmod>` : null,
            e.changefreq ? `    <changefreq>${e.changefreq}</changefreq>` : null,
            e.priority ? `    <priority>${e.priority}</priority>` : null,
            `  </url>`,
          ]
            .filter(Boolean)
            .join("\n"),
        );

        const xml = [
          `<?xml version="1.0" encoding="UTF-8"?>`,
          `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
          ...urls,
          `</urlset>`,
        ].join("\n");

        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml",
            "Cache-Control": "public, max-age=3600",
          },
        });
      },
    },
  },
});

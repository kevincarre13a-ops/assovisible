import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page introuvable</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          La page que vous recherchez n'existe pas.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Retour à l'accueil
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "AssoVisible — Sites web pour associations loi 1901" },
      {
        name: "description",
        content:
          "Agence web spécialisée dans la création de sites internet pour les associations françaises. Accompagnement humain, hébergement inclus, prix transparents.",
      },
      { property: "og:title", content: "AssoVisible — Sites web pour associations loi 1901" },
      {
        property: "og:description",
        content:
          "Sites web professionnels et durables pour associations loi 1901. Devis gratuit.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:title", content: "AssoVisible — Sites web pour associations loi 1901" },
      { name: "twitter:description", content: "Créez le site internet de votre association en quelques jours. Site moderne, accompagnement humain, hébergement inclus. À partir de 290€." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/df305823-67d3-4e88-a601-f77d087ff38c/id-preview-c94a0067--1d415c3a-fca0-4ba0-94ca-809868c2540a.lovable.app-1777973885959.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/df305823-67d3-4e88-a601-f77d087ff38c/id-preview-c94a0067--1d415c3a-fca0-4ba0-94ca-809868c2540a.lovable.app-1777973885959.png" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" },
      { rel: "stylesheet", href: appCss },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return (
    <div className="min-h-screen flex flex-col bg-cream">
      <Header />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}

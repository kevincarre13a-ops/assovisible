import { createFileRoute, Link } from "@tanstack/react-router";
import { Sparkles, ArrowRight } from "lucide-react";
import { Reveal } from "@/components/Reveal";

export const Route = createFileRoute("/guide")({
  head: () => ({
    meta: [
      { title: "Guide gratuit — 10 questions avant de créer votre site asso" },
      {
        name: "description",
        content:
          "Le guide gratuit AssoVisible : 10 questions clés pour cadrer le site web de votre association loi 1901 avant de vous lancer. Téléchargez-le en un clic.",
      },
      { property: "og:title", content: "Guide gratuit — 10 questions avant de créer votre site asso" },
      {
        property: "og:description",
        content:
          "Le guide gratuit AssoVisible : 10 questions clés pour cadrer le site web de votre association loi 1901 avant de vous lancer. Téléchargez-le en un clic.",
      },
    ],
  }),
  component: GuidePage,
});

const questions = [
  {
    category: "OBJECTIF",
    title: "Pourquoi votre association a-t-elle besoin d'un site aujourd'hui ?",
    text: "Recruter des bénévoles, trouver des financeurs, informer vos adhérents… L'objectif principal conditionne tout le reste.",
  },
  {
    category: "PUBLIC CIBLE",
    title: "À qui s'adresse votre site en priorité ?",
    text: "Adhérents existants, grand public, partenaires institutionnels, donateurs ? Chaque cible implique un contenu et un design différent.",
  },
  {
    category: "CONTENU",
    title: "De quelles pages avez-vous réellement besoin ?",
    text: "Accueil, présentation, équipe, agenda, actualités, contact, espace adhérents… Ne payez que ce dont vous avez besoin.",
  },
  {
    category: "BUDGET",
    title: "Quel budget avez-vous prévu — et avez-vous l'accord de votre CA ?",
    text: "En association, les dépenses sont votées en assemblée. Anticiper évite de trouver le prestataire idéal… sans pouvoir le payer.",
  },
  {
    category: "AUTONOMIE",
    title: "Qui va mettre à jour le site une fois livré ?",
    text: "Si personne en interne ne peut le faire, prévoyez une option maintenance. Sinon, assurez-vous d'avoir une formation incluse.",
  },
  {
    category: "FONCTIONNALITÉS",
    title: "Avez-vous besoin de collecter des dons ou des adhésions en ligne ?",
    text: "Si oui, une intégration HelloAsso ou Stripe est indispensable. Vérifiez que le prestataire la maîtrise.",
  },
  {
    category: "DÉLAIS",
    title: "Avez-vous une échéance proche (AG, événement, subvention) ?",
    text: "Un site livré en 5 jours et un site livré en 3 mois ne se comparent pas de la même façon si vous avez un calendrier contraint.",
  },
  {
    category: "HÉBERGEMENT",
    title: "L'hébergement et le nom de domaine sont-ils inclus dans le devis ?",
    text: "Certains prestataires facturent séparément. Vérifiez aussi où sont hébergées vos données (France ou étranger).",
  },
  {
    category: "IDENTITÉ VISUELLE",
    title: "Avez-vous déjà un logo, des couleurs ou une charte graphique ?",
    text: "Si non, prévoyez-le dans le budget. Si oui, fournissez-les en haute résolution pour un résultat professionnel.",
  },
  {
    category: "ENGAGEMENT",
    title: "Le contrat engage-t-il votre association sur la durée ?",
    text: "Abonnement mensuel ou paiement unique ? En association, un engagement pluriannuel doit être approuvé par l'assemblée. Préférez un paiement unique quand c'est possible.",
  },
];

function GuidePage() {
  return (
    <>
      {/* HERO */}
      <section className="relative py-24 mesh-bg grain overflow-hidden">
        <div aria-hidden className="absolute -top-20 right-1/4 h-72 w-72 rounded-full bg-sage/25 blur-3xl animate-blob" />
        <div aria-hidden className="absolute bottom-0 left-1/4 h-80 w-80 rounded-full bg-gold/20 blur-3xl animate-blob" style={{ animationDelay: "4s" }} />
        <div className="container-wide relative text-center max-w-4xl mx-auto">
          <span className="chip"><Sparkles className="h-3.5 w-3.5" /> Guide gratuit · AssoVisible</span>
          <h1 className="mt-6 font-display text-4xl md:text-5xl lg:text-6xl tracking-tight">
            10 questions à poser <span className="text-gradient-gold">avant de créer le site</span> de votre association
          </h1>
          <p className="mt-6 text-lg md:text-xl text-ink/65 leading-relaxed">
            Un outil simple pour cadrer votre projet avant de vous lancer. Conçu par notre équipe pour les présidents et bureaux d'associations loi 1901.
          </p>
        </div>
      </section>

      {/* QUESTIONS */}
      <section className="py-20">
        <div className="container-wide max-w-3xl">
          <div className="space-y-5">
            {questions.map((q, i) => (
              <Reveal key={q.title} delay={i * 40}>
                <article className="card-premium p-6 md:p-7 flex gap-5 items-start">
                  <div className="h-12 w-12 shrink-0 rounded-full bg-sage text-cream flex items-center justify-center font-display text-xl font-bold shadow-md">
                    {i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-sans font-bold tracking-wider text-sage">
                      {q.category}
                    </p>
                    <h2 className="mt-1.5 font-display text-xl md:text-2xl text-primary leading-snug">
                      {q.title}
                    </h2>
                    <p className="mt-3 text-ink/70 text-[15px] leading-relaxed">
                      {q.text}
                    </p>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="py-20">
        <div className="container-wide max-w-4xl">
          <Reveal>
            <div className="relative rounded-3xl overflow-hidden p-10 md:p-14 bg-gradient-to-br from-gold/15 via-cream to-sage/15 border border-gold/30 grain text-center">
              <div aria-hidden className="absolute -top-24 -right-24 h-72 w-72 rounded-full bg-gold/25 blur-3xl animate-blob" />
              <div aria-hidden className="absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-sage/25 blur-3xl animate-blob" style={{ animationDelay: "3s" }} />
              <h2 className="relative font-display text-3xl md:text-4xl text-primary">
                Vous avez vos réponses ? On s'occupe du reste.
              </h2>
              <p className="relative mt-5 text-ink/75 text-lg max-w-2xl mx-auto leading-relaxed">
                Maquette de votre site offerte en 48h, sans engagement. Si elle ne vous convient pas, vous ne devez rien.
              </p>
              <Link to="/contact" className="relative mt-8 btn-primary inline-flex">
                Obtenir ma maquette gratuite
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { Phone, Mail, MapPin, Clock, ShieldCheck, ChevronDown, CheckCircle2, Sparkles } from "lucide-react";
import { Reveal } from "@/components/Reveal";
import { sendContactEmail } from "@/lib/contact.functions";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact & devis gratuit pour site associatif | AssoVisible" },
      { name: "description", content: "Contactez AssoVisible pour un devis gratuit et une maquette offerte en 48h. Réponse garantie sous 24h ouvrées, premier échange toujours sans engagement." },
      { property: "og:title", content: "Contact & devis gratuit pour site associatif | AssoVisible" },
      { property: "og:description", content: "Contactez AssoVisible pour un devis gratuit et une maquette offerte en 48h. Réponse garantie sous 24h ouvrées, premier échange toujours sans engagement." },
    ],
  }),
  component: ContactPage,
});

const schema = z.object({
  name: z.string().trim().min(2, "Nom requis").max(100),
  email: z.string().trim().email("Email invalide").max(255),
  phone: z.string().trim().max(30).optional().or(z.literal("")),
  asso: z.string().trim().min(2, "Nom de l'association requis").max(150),
  type: z.string().min(1, "Type requis"),
  message: z.string().trim().min(10, "Décrivez votre projet en quelques mots").max(2000),
  source: z.string().optional(),
});

const faq = [
  {
    q: "Combien coûte un site pour une association ?",
    a: "Notre forfait Essentiel est à 290€ pour un site vitrine de 5 pages, avec hébergement inclus la première année. Paiement en 3 fois sans frais possible (3 × 97€).",
  },
  {
    q: "Combien de temps faut-il pour créer notre site ?",
    a: "Comptez en moyenne 4 à 6 semaines entre le premier échange et la mise en ligne. Tout dépend de la disponibilité de vos contenus (textes, photos) et du nombre de validations.",
  },
  {
    q: "Avons-nous besoin de connaissances techniques ?",
    a: "Aucune connaissance technique n'est nécessaire. Nous nous occupons de tout : création, hébergement, sécurité. Et nous vous formons à la fin pour que vous puissiez modifier vos contenus en toute autonomie.",
  },
  {
    q: "Le site sera-t-il accessible sur mobile ?",
    a: "Oui, tous nos sites sont conçus en priorité pour les smartphones et tablettes — c'est aujourd'hui le premier écran de la plupart des visiteurs. Ils respectent aussi les standards d'accessibilité (WCAG AA).",
  },
  {
    q: "Que se passe-t-il après la mise en ligne ?",
    a: "Nous restons à vos côtés : maintenance, sauvegardes, mises à jour de sécurité, et support humain sous 24h ouvrées. Votre interlocuteur dédié reste le même au fil des années.",
  },
];

function ContactPage() {
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const data = Object.fromEntries(fd.entries());
    const parsed = schema.safeParse(data);
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      parsed.error.issues.forEach((i) => (errs[i.path[0] as string] = i.message));
      setErrors(errs);
      return;
    }
    setErrors({});
    setServerError(null);
    setLoading(true);
    try {
      await sendContactEmail({ data: parsed.data });
      setSubmitted(true);
    } catch (err) {
      console.error(err);
      setServerError("Envoi impossible pour le moment. Réessayez ou écrivez-nous directement à contact@assovisible.fr.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <section className="relative py-24 mesh-bg grain overflow-hidden">
        <div aria-hidden className="absolute -top-20 right-1/4 h-72 w-72 rounded-full bg-gold/25 blur-3xl animate-blob" />
        <div aria-hidden className="absolute bottom-0 left-1/4 h-80 w-80 rounded-full bg-sage/20 blur-3xl animate-blob" style={{ animationDelay: "4s" }} />
        <div className="container-wide relative text-center max-w-3xl mx-auto">
          <span className="chip"><Sparkles className="h-3.5 w-3.5" /> Contact</span>
          <h1 className="mt-6 font-display text-5xl md:text-6xl lg:text-7xl tracking-tight">
            Parlons de votre <span className="text-gradient-gold">projet</span>
          </h1>
          <p className="mt-6 text-lg md:text-xl text-ink/65 leading-relaxed">
            Premier échange toujours gratuit et sans engagement. Réponse garantie sous 24h ouvrées.
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="container-prose grid lg:grid-cols-5 gap-12">
          <div className="lg:col-span-3">
            <Reveal>
              <div className="bg-card border border-border rounded-xl p-8 md:p-10 shadow-soft">
                {submitted ? (
                  <div className="text-center py-12">
                    <CheckCircle2 className="h-16 w-16 text-sage mx-auto" />
                    <h2 className="mt-6 font-display text-3xl">Merci pour votre message !</h2>
                    <p className="mt-3 text-ink/70">
                      Nous revenons vers vous sous 24h ouvrées, par email ou par téléphone.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={onSubmit} className="grid sm:grid-cols-2 gap-5 font-sans">
                    <Field label="Nom et prénom" name="name" required error={errors.name} />
                    <Field label="Email" name="email" type="email" required error={errors.email} />
                    <Field label="Téléphone" name="phone" type="tel" error={errors.phone} />
                    <Field label="Nom de l'association" name="asso" required error={errors.asso} />
                    <SelectField
                      label="Type d'association"
                      name="type"
                      required
                      error={errors.type}
                      options={["Culturelle", "Sportive", "Caritative / Solidarité", "Environnement", "Éducation", "Patrimoine", "Autre"]}
                    />
                    <SelectField
                      label="Comment nous avez-vous trouvés ?"
                      name="source"
                      options={["Recherche Google", "Recommandation", "Réseaux sociaux", "Presse / Article", "Autre"]}
                    />
                    <div className="sm:col-span-2">
                      <label className="block text-sm font-semibold text-primary mb-1.5">
                        Votre projet <span className="text-destructive">*</span>
                      </label>
                      <textarea
                        name="message"
                        rows={5}
                        required
                        className="w-full rounded-md border border-input bg-cream px-4 py-3 text-base font-serif focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent"
                        placeholder="Parlez-nous brièvement de votre association et de vos besoins..."
                      />
                      {errors.message && <p className="text-sm text-destructive mt-1">{errors.message}</p>}
                    </div>
                    {serverError && (
                      <div className="sm:col-span-2 rounded-md border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-destructive">
                        {serverError}
                      </div>
                    )}
                    <div className="sm:col-span-2 flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2">
                      <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                        <ShieldCheck className="h-4 w-4 text-sage" /> Vos données restent strictement confidentielles.
                      </p>
                      <button
                        type="submit"
                        disabled={loading}
                        className="rounded-md bg-primary text-cream px-7 py-4 font-semibold hover:brightness-110 transition disabled:opacity-60"
                      >
                        {loading ? "Envoi en cours..." : "Envoyer ma demande"}
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </Reveal>
          </div>

          <aside className="lg:col-span-2 space-y-6">
            <Reveal>
              <div className="bg-primary text-cream rounded-xl p-8">
                <Clock className="h-7 w-7 text-gold" />
                <h3 className="mt-4 font-display text-cream text-2xl">Réponse sous 24h ouvrées</h3>
                <p className="mt-2 text-cream/75 text-[15px]">
                  Premier échange toujours gratuit et sans engagement.
                </p>
              </div>
            </Reveal>
            <Reveal delay={80}>
              <div className="bg-card border border-border rounded-xl p-8 space-y-5 font-sans">
                <a href="tel:+33647474581" className="flex items-start gap-4 hover:text-gold transition">
                  <Phone className="h-5 w-5 text-gold mt-1" />
                  <div>
                    <div className="font-semibold text-primary">06 47 47 45 81</div>
                    <div className="text-sm text-muted-foreground">Lun-Ven, 9h-18h</div>
                  </div>
                </a>
                <a href="mailto:contact@assovisible.fr" className="flex items-start gap-4 hover:text-gold transition">
                  <Mail className="h-5 w-5 text-gold mt-1" />
                  <div>
                    <div className="font-semibold text-primary">contact@assovisible.fr</div>
                    <div className="text-sm text-muted-foreground">Réponse sous 24h</div>
                  </div>
                </a>
                <div className="flex items-start gap-4">
                  <MapPin className="h-5 w-5 text-gold mt-1" />
                  <div>
                    <div className="font-semibold text-primary">France</div>
                  </div>
                </div>
              </div>
            </Reveal>
          </aside>
        </div>
      </section>

      <section className="py-24 bg-secondary/40">
        <div className="container-prose max-w-3xl">
          <div className="text-center mb-12">
            <span className="font-sans text-sm font-semibold uppercase tracking-[0.2em] text-gold">FAQ</span>
            <h2 className="mt-4 font-display text-4xl">Questions fréquentes</h2>
          </div>
          <div className="space-y-3">
            {faq.map((f, i) => (
              <div key={f.q} className="bg-card border border-border rounded-lg overflow-hidden">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between gap-4 p-6 text-left"
                >
                  <span className="font-display text-xl text-primary">{f.q}</span>
                  <ChevronDown
                    className={`h-5 w-5 shrink-0 text-gold transition-transform ${openFaq === i ? "rotate-180" : ""}`}
                  />
                </button>
                {openFaq === i && (
                  <div className="px-6 pb-6 text-ink/75 leading-relaxed">{f.a}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}

function Field({
  label,
  name,
  type = "text",
  required,
  error,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
  error?: string;
}) {
  return (
    <div>
      <label className="block text-sm font-semibold text-primary mb-1.5">
        {label} {required && <span className="text-destructive">*</span>}
      </label>
      <input
        type={type}
        name={name}
        required={required}
        className="w-full rounded-md border border-input bg-cream px-4 py-3 text-base font-serif focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent"
      />
      {error && <p className="text-sm text-destructive mt-1">{error}</p>}
    </div>
  );
}

function SelectField({
  label,
  name,
  required,
  options,
  error,
}: {
  label: string;
  name: string;
  required?: boolean;
  options: string[];
  error?: string;
}) {
  return (
    <div>
      <label className="block text-sm font-semibold text-primary mb-1.5">
        {label} {required && <span className="text-destructive">*</span>}
      </label>
      <select
        name={name}
        required={required}
        defaultValue=""
        className="w-full rounded-md border border-input bg-cream px-4 py-3 text-base font-serif focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent"
      >
        <option value="" disabled>Sélectionnez...</option>
        {options.map((o) => (
          <option key={o} value={o}>{o}</option>
        ))}
      </select>
      {error && <p className="text-sm text-destructive mt-1">{error}</p>}
    </div>
  );
}

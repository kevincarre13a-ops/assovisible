import { createFileRoute, Link } from "@tanstack/react-router";
import { Linkedin, Heart, Eye, HandHeart, Sparkles, ArrowRight } from "lucide-react";
import { Reveal } from "@/components/Reveal";
import { SectionHeading } from "./index";

export const Route = createFileRoute("/a-propos")({
  head: () => ({
    meta: [
      { title: "À propos — Agence web pour associations | AssoVisible" },
      { name: "description", content: "AssoVisible, une équipe française de passionnés au service des associations loi 1901. Notre histoire, nos valeurs, notre équipe. Échangeons sur votre projet." },
      { property: "og:title", content: "À propos — Agence web pour associations | AssoVisible" },
      { property: "og:description", content: "AssoVisible, une équipe française de passionnés au service des associations loi 1901. Notre histoire, nos valeurs, notre équipe. Échangeons sur votre projet." },
    ],
  }),
  component: AboutPage,
});

const team = [
  { initials: "KV", name: "Kévin", role: "Fondateur & chef de projet", bio: "Il a créé AssoVisible pour offrir aux associations un accompagnement web simple, honnête et à leur portée." },
  { initials: "ED", name: "Erwan Defever", role: "Développeur web", bio: "Il prend en charge l'intégration et le développement technique des sites, pour que tout fonctionne parfaitement à la livraison." },
  { initials: "JG", name: "Julien Galan", role: "Développeur web", bio: "Il intervient sur la conception et l'optimisation des sites, avec un œil particulier sur les performances et le référencement." },
  { initials: "YC", name: "Yohan Chemin", role: "Designer & communication visuelle", bio: "Il conçoit les maquettes, les visuels et les supports de communication — flyers, affiches — dans un style moderne et accessible." },
];

function AboutPage() {
  return (
    <>
      <section className="relative py-24 mesh-bg grain overflow-hidden">
        <div aria-hidden className="absolute -top-20 left-1/4 h-72 w-72 rounded-full bg-gold/25 blur-3xl animate-blob" />
        <div aria-hidden className="absolute bottom-0 right-1/4 h-80 w-80 rounded-full bg-sage/20 blur-3xl animate-blob" style={{ animationDelay: "4s" }} />
        <div className="container-wide relative text-center max-w-3xl mx-auto">
          <span className="chip"><Sparkles className="h-3.5 w-3.5" /> À propos</span>
          <h1 className="mt-6 font-display text-5xl md:text-6xl lg:text-7xl tracking-tight">
            Nous croyons au pouvoir des <span className="text-gradient-gold">associations</span>.
          </h1>
          <p className="mt-6 text-lg text-ink/75">
            AssoVisible, c'est une équipe de passionnés du web au service du monde associatif français.
          </p>
        </div>
      </section>

      <section className="py-24">
        <div className="container-prose grid lg:grid-cols-3 gap-12">
          <div className="lg:col-span-1">
            <Reveal>
              <h2 className="font-display text-3xl">Notre histoire</h2>
            </Reveal>
          </div>
          <div className="lg:col-span-2 space-y-5 text-ink/80 text-[18px] leading-relaxed font-serif">
            <Reveal>
              <p>
                AssoVisible est née d'un constat simple : les associations françaises,
                qui font tant pour la société, sont trop souvent mal accompagnées sur le
                numérique. Devis opaques, sites livrés sans formation, prestataires qui
                disparaissent au premier souci.
              </p>
            </Reveal>
            <Reveal delay={80}>
              <p>
                Kévin a créé AssoVisible pour changer ça. L'idée : proposer aux associations
                loi 1901 un accompagnement honnête, des tarifs transparents et un suivi
                humain — sans jargon, sans mauvaise surprise.
              </p>
            </Reveal>
            <Reveal delay={120}>
              <p>
                Aujourd'hui, plus de 127 associations nous ont fait confiance — culturelles,
                sportives, caritatives, environnementales — partout en France.
              </p>
            </Reveal>
          </div>
        </div>
      </section>

      <section className="py-24 bg-secondary/40">
        <div className="container-prose">
          <Reveal>
            <SectionHeading eyebrow="L'équipe" title="Des visages, pas des numéros de ticket" />
          </Reveal>
          <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((m, i) => (
              <Reveal key={m.name} delay={i * 80}>
                <div className="bg-card border border-border rounded-xl p-8 text-center">
                  <div className="mx-auto h-24 w-24 rounded-full bg-primary/10 flex items-center justify-center font-display text-3xl text-primary">
                    {m.initials}
                  </div>
                  <h3 className="font-display text-xl mt-5">{m.name}</h3>
                  <p className="font-sans text-xs uppercase tracking-wider text-gold mt-1">{m.role}</p>
                  <p className="mt-3 text-[15px] text-ink/75 leading-relaxed">{m.bio}</p>
                  <a href="#" aria-label={`LinkedIn de ${m.name}`} className="inline-flex mt-4 h-8 w-8 items-center justify-center rounded-md bg-primary/5 text-primary hover:bg-primary hover:text-cream transition">
                    <Linkedin className="h-4 w-4" />
                  </a>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="container-prose">
          <Reveal>
            <SectionHeading eyebrow="Nos valeurs" title="Trois engagements, tenus depuis le premier jour." />
          </Reveal>
          <div className="mt-14 grid md:grid-cols-3 gap-8">
            {[
              { icon: Eye, title: "Accessibilité", text: "Nos sites sont conçus pour être utilisables par tous, y compris les bénévoles peu à l'aise avec le numérique." },
              { icon: HandHeart, title: "Transparence", text: "Devis détaillés, tarifs publics, contrats clairs. Pas de surprise, jamais." },
              { icon: Heart, title: "Engagement", text: "Nous ne travaillons qu'avec les associations. C'est notre métier, pas une diversification." },
            ].map((v, i) => (
              <Reveal key={v.title} delay={i * 100}>
                <div className="text-center">
                  <div className="mx-auto h-16 w-16 rounded-full bg-gold/15 flex items-center justify-center">
                    <v.icon className="h-7 w-7 text-gold" />
                  </div>
                  <h3 className="font-display text-2xl mt-5">{v.title}</h3>
                  <p className="mt-3 text-ink/75">{v.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 border-y border-border bg-cream">
        <div className="container-prose text-center">
          <p className="font-sans text-sm uppercase tracking-widest text-muted-foreground mb-8">
            Nos partenaires techniques
          </p>
          <div className="flex flex-wrap justify-center gap-x-12 gap-y-6 items-center font-display text-2xl text-primary/40">
            <span>Stripe</span>
            <span>WordPress</span>
            <span>OVH</span>
            <span>HelloAsso</span>
            <span>Brevo</span>
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="container-wide">
          <div className="relative rounded-3xl overflow-hidden mesh-bg-dark text-cream p-12 md:p-16 text-center grain">
            <div aria-hidden className="absolute -top-20 -left-20 h-80 w-80 rounded-full bg-gold/25 blur-3xl animate-blob" />
            <div aria-hidden className="absolute -bottom-20 -right-20 h-80 w-80 rounded-full bg-sage/20 blur-3xl animate-blob" style={{ animationDelay: "5s" }} />
            <div className="relative max-w-2xl mx-auto">
              <h2 className="font-display text-cream text-4xl md:text-5xl mt-5 leading-tight">
                Un projet en <span className="text-gradient-gold">tête</span> ?
              </h2>
              <p className="mt-5 text-cream/75 text-lg">
                Premier échange toujours gratuit, sans engagement. Réponse sous 24h.
              </p>
              <Link to="/contact" className="mt-9 btn-gold inline-flex">
                Obtenir ma maquette gratuite
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

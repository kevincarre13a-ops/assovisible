import { createFileRoute, notFound } from "@tanstack/react-router";
import { BlogArticle } from "@/components/BlogArticle";
import { getPost } from "@/lib/blog-posts";
import { getArticleContent } from "@/lib/blog-content";

export const Route = createFileRoute("/blog/$slug")({
  loader: ({ params }) => {
    const post = getPost(params.slug);
    if (!post) throw notFound();
    return { post };
  },
  head: ({ loaderData }) => {
    if (!loaderData) return {};
    const { post } = loaderData;
    const url = `https://assovisible.fr/blog/${post.slug}`;
    return {
      meta: [
        { title: post.metaTitle },
        { name: "description", content: post.metaDescription },
        { property: "og:title", content: post.metaTitle },
        { property: "og:description", content: post.metaDescription },
        { property: "og:type", content: "article" },
        { property: "og:url", content: url },
      ],
      links: [{ rel: "canonical", href: url }],
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Article",
            headline: post.title,
            datePublished: post.date,
            dateModified: post.date,
            author: { "@type": "Organization", name: "AssoVisible" },
            publisher: { "@type": "Organization", name: "AssoVisible" },
            mainEntityOfPage: url,
          }),
        },
      ],
    };
  },
  notFoundComponent: () => (
    <div className="container-wide py-32 text-center">
      <h1 className="font-display text-4xl text-primary">Article introuvable</h1>
      <p className="mt-4 text-ink/70">Cet article n'existe pas ou a été déplacé.</p>
    </div>
  ),
  component: BlogPostPage,
});



function BlogPostPage() {
  const { post } = Route.useLoaderData();
  const content = getArticleContent(post.slug);
  return <BlogArticle post={post}>{content}</BlogArticle>;
}

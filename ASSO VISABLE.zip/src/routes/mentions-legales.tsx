import { createFileRoute, Link } from "@tanstack/react-router";
import { Reveal } from "@/components/Reveal";
import { ScrollText, Building2, UserCheck, Server, BrainCircuit, AlertTriangle, Scale, Mail, ChevronRight, CalendarDays } from "lucide-react";

export const Route = createFileRoute("/mentions-legales")({
  head: () => ({
    meta: [
      { title: "Mentions légales du site assovisible.fr | AssoVisible" },
      { name: "description", content: "Mentions légales d'AssoVisible : éditeur, hébergeur, propriété intellectuelle et responsabilité du site assovisible.fr. Contactez-nous pour toute question." },
      { property: "og:title", content: "Mentions légales du site assovisible.fr | AssoVisible" },
      { property: "og:description", content: "Mentions légales d'AssoVisible : éditeur, hébergeur, propriété intellectuelle et responsabilité du site assovisible.fr. Contactez-nous pour toute question." },
    ],
  }),
  component: MentionsPage,
});

const sections = [
  {
    id: "editeur",
    icon: Building2,
    title: "1. Identification de l'éditeur du site",
    content: (
      <>
        <p>Le présent site assovisible.fr est édité par :</p>
        <ul className="space-y-2 list-disc pl-5 mt-4">
          <li><strong>Nom :</strong> Kevin Carré</li>
          <li><strong>Statut juridique :</strong> Auto-entrepreneur (micro-entreprise)</li>
          <li><strong>Activité :</strong> Création et vente de sites web, services digitaux</li>
          <li><strong>Adresse :</strong> Aix-en-Provence, France</li>
          <li><strong>Email :</strong> <a href="mailto:contact@assovisible.fr" className="text-gold hover:underline">contact@assovisible.fr</a></li>
          <li><strong>Nom commercial :</strong> AssoVisible</li>
          <li><strong>TVA intracommunautaire :</strong> Non applicable (franchise en base — art. 293 B du CGI)</li>
        </ul>
      </>
    ),
  },
  {
    id: "publication",
    icon: UserCheck,
    title: "2. Responsable de publication",
    content: (
      <>
        <p>Le responsable de la publication du site est <strong>Kevin Carré</strong>, en qualité d'auto-entrepreneur.</p>
        <p className="mt-4">Pour toute question ou demande relative au contenu publié sur le site, vous pouvez le contacter à l'adresse <a href="mailto:contact@assovisible.fr" className="text-gold hover:underline">contact@assovisible.fr</a>.</p>
      </>
    ),
  },
  {
    id: "hebergeur",
    icon: Server,
    title: "3. Hébergeur",
    content: (
      <>
        <p>Le site assovisible.fr est hébergé par :</p>
        <ul className="space-y-2 list-disc pl-5 mt-4">
          <li><strong>Hébergeur :</strong> Lovable</li>
          <li><strong>Site web :</strong> <a href="https://lovable.dev" target="_blank" rel="noreferrer" className="text-gold hover:underline">lovable.dev</a></li>
        </ul>
      </>
    ),
  },
  {
    id: "propriete",
    icon: BrainCircuit,
    title: "4. Propriété intellectuelle",
    content: (
      <>
        <p>L'ensemble du contenu présent sur le site assovisible.fr — incluant, de manière non exhaustive, les textes, images, graphismes, logos, icônes, photographies, vidéos, mises en page, codes sources et éléments interactifs — est la propriété exclusive de Kevin Carré (AssoVisible), sauf mention contraire.</p>
        <p className="mt-4">Ces contenus sont protégés par les lois françaises et internationales relatives au droit d'auteur et à la propriété intellectuelle. Toute reproduction, représentation, modification, publication, transmission ou exploitation, totale ou partielle, sans autorisation écrite préalable, est strictement interdite et constitue une contrefaçon sanctionnée par les articles L.335-2 et suivants du Code de la propriété intellectuelle.</p>
      </>
    ),
  },
  {
    id: "responsabilite",
    icon: AlertTriangle,
    title: "5. Responsabilité",
    content: (
      <>
        <p>Les informations diffusées sur le site sont présentées à titre indicatif et sont susceptibles d'évoluer. Kevin Carré (AssoVisible) s'efforce d'assurer l'exactitude et la mise à jour des informations publiées, sans toutefois pouvoir garantir l'absence totale d'erreurs ou d'omissions.</p>
        <p className="mt-4">L'éditeur ne saurait être tenu pour responsable des dommages directs ou indirects résultant de l'accès au site, de son utilisation, de l'impossibilité d'y accéder, ou du crédit accordé à une quelconque information qui en proviendrait directement ou indirectement.</p>
        <p className="mt-4">Concernant les prestations de services digitaux fournies, la responsabilité de l'éditeur est strictement limitée au montant des sommes effectivement versées par le client pour la prestation concernée. L'éditeur ne pourra en aucun cas être tenu responsable de la perte de données, de la perte d'exploitation, du préjudice commercial ou de tout dommage indirect subi par le client.</p>
      </>
    ),
  },
  {
    id: "droit",
    icon: Scale,
    title: "6. Droit applicable",
    content: (
      <>
        <p>Les présentes mentions légales sont régies par le droit français. En cas de litige relatif à leur interprétation ou à leur exécution, et à défaut de résolution amiable, compétence exclusive est attribuée aux tribunaux français compétents.</p>
      </>
    ),
  },
];

function MentionsPage() {
  return (
    <>
      <section className="relative py-20 md:py-28 mesh-bg grain overflow-hidden">
        <div aria-hidden className="absolute -top-20 right-1/4 h-72 w-72 rounded-full bg-gold/20 blur-3xl animate-blob" />
        <div aria-hidden className="absolute bottom-0 left-1/4 h-80 w-80 rounded-full bg-sage/15 blur-3xl animate-blob" style={{ animationDelay: "4s" }} />
        <div className="container-wide relative text-center max-w-3xl mx-auto">
          <span className="chip"><ScrollText className="h-3.5 w-3.5" /> Documents légaux</span>
          <h1 className="mt-6 font-display text-4xl md:text-5xl lg:text-6xl tracking-tight">
            Mentions <span className="text-gradient-gold">légales</span>
          </h1>
          <p className="mt-5 text-lg md:text-xl text-ink/65 leading-relaxed">
            Informations légales relatives à l'éditeur du site assovisible.fr.
          </p>
          <div className="mt-6 inline-flex items-center gap-2 text-sm text-muted-foreground font-sans">
            <CalendarDays className="h-4 w-4" />
            Dernière mise à jour : 18 juin 2026
          </div>
        </div>
      </section>

      <section className="py-10 bg-secondary/30">
        <div className="container-prose max-w-4xl">
          <Reveal>
            <div className="bg-card border border-border rounded-xl p-6 md:p-8">
              <h2 className="font-display text-xl mb-4">Sommaire</h2>
              <nav className="grid sm:grid-cols-2 gap-2">
                {sections.map((s) => (
                  <a key={s.id} href={`#${s.id}`} className="flex items-center gap-2 py-1.5 px-3 rounded-md text-sm text-ink/80 hover:bg-primary/5 hover:text-primary transition-colors">
                    <ChevronRight className="h-3.5 w-3.5 text-gold shrink-0" />
                    {s.title}
                  </a>
                ))}
              </nav>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="container-prose max-w-3xl space-y-16">
          {sections.map((s, i) => {
            const Icon = s.icon;
            return (
              <Reveal key={s.id} delay={i % 3 === 0 ? 0 : i % 3 === 1 ? 40 : 80}>
                <article id={s.id} className="scroll-mt-28">
                  <div className="flex items-start gap-4 mb-5">
                    <div className="hidden sm:flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gold/10 text-gold">
                      <Icon className="h-5 w-5" />
                    </div>
                    <h2 className="font-display text-2xl md:text-3xl pt-0.5">{s.title}</h2>
                  </div>
                  <div className="prose prose-lg max-w-none text-ink/80 leading-relaxed font-serif">
                    {s.content}
                  </div>
                  {i < sections.length - 1 && <div className="mt-10 border-b border-border" />}
                </article>
              </Reveal>
            );
          })}
        </div>
      </section>

      <section className="py-20 bg-primary text-cream relative overflow-hidden grain">
        <div aria-hidden className="absolute -top-20 -right-20 h-72 w-72 rounded-full bg-gold/15 blur-3xl animate-blob" />
        <div aria-hidden className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full bg-sage/15 blur-3xl animate-blob" style={{ animationDelay: "5s" }} />
        <div className="container-wide relative text-center max-w-2xl mx-auto">
          <h2 className="font-display text-3xl md:text-4xl">Une question ?</h2>
          <p className="mt-4 text-cream/75 text-lg">N'hésitez pas à nous contacter pour toute demande d'information.</p>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/contact" className="btn-gold">Nous contacter</Link>
            <a href="mailto:contact@assovisible.fr" className="btn-ghost !text-cream !border-cream/20 hover:!bg-cream/10">
              <Mail className="h-4 w-4" /> contact@assovisible.fr
            </a>
          </div>
        </div>
      </section>
    </>
  );
}

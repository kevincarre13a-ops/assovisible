import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Sparkles,
  Check,
  ArrowRight,
  Clock,
  Eye,
  Shield,
  Smartphone,
  GraduationCap,
  CreditCard,
  Printer,
  FileImage,
  Palette,
  Truck,
  Files,
} from "lucide-react";
import { Reveal } from "@/components/Reveal";
import { SectionHeading } from "./index";
import { CTA } from "./realisations";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Création de site web pour associations | AssoVisible" },
      {
        name: "description",
        content:
          "Site associatif livré en 5 jours, hébergement français inclus, plus flyers et affiches sur devis. Demandez votre maquette gratuite en 48h, sans engagement.",
      },
      { property: "og:title", content: "Création de site web pour associations | AssoVisible" },
      {
        property: "og:description",
        content:
          "Site associatif livré en 5 jours, hébergement français inclus, plus flyers et affiches sur devis. Demandez votre maquette gratuite en 48h, sans engagement.",
      },
    ],
  }),
  component: ServicesPage,
});

const webBenefits = [
  { icon: Clock, text: "Livraison en 5 jours chrono" },
  { icon: Eye, text: "Maquette offerte en 48h, sans engagement" },
  { icon: Shield, text: "Hébergement inclus, sécurisé en France 🇫🇷" },
  { icon: Smartphone, text: "100% adapté mobile & tablette" },
  { icon: GraduationCap, text: "Formation incluse pour gérer votre site en autonomie" },
  { icon: CreditCard, text: "Paiement en 3× sans frais" },
];

const printBenefits = [
  { icon: Clock, text: "Livraison du fichier sous 48h" },
  { icon: Palette, text: "Design cohérent avec l'identité de votre site (si créé avec nous)" },
  { icon: Files, text: "Fichiers prêts à imprimer fournis systématiquement" },
  { icon: Truck, text: "Impression prise en charge et livraison directe à votre adresse" },
  { icon: Printer, text: "Tarif impression sur devis selon les quantités" },
];

function ServicesPage() {
  return (
    <>
      {/* HERO */}
      <section className="relative py-24 mesh-bg grain overflow-hidden">
        <div aria-hidden className="absolute -top-20 right-1/4 h-72 w-72 rounded-full bg-sage/25 blur-3xl animate-blob" />
        <div aria-hidden className="absolute bottom-0 left-1/4 h-80 w-80 rounded-full bg-gold/20 blur-3xl animate-blob" style={{ animationDelay: "4s" }} />
        <div className="container-wide relative text-center max-w-4xl mx-auto">
          <span className="chip"><Sparkles className="h-3.5 w-3.5" /> Nos services</span>
          <h1 className="mt-6 font-display text-4xl md:text-5xl lg:text-6xl tracking-tight">
            Deux expertises, un seul objectif :{" "}
            <span className="text-gradient-gold">rendre votre association visible.</span>
          </h1>
          <p className="mt-6 text-lg md:text-xl text-ink/65 leading-relaxed">
            Création de site web et communication imprimée. Tout ce qu'il faut pour exister en ligne et sur le terrain.
          </p>
        </div>
      </section>

      {/* SERVICE 1 — SITE WEB */}
      <section className="py-24 relative">
        <div className="container-wide">
          <Reveal>
            <div className="max-w-3xl mx-auto text-center">
              <span className="chip"><Sparkles className="h-3.5 w-3.5" /> Service n°1</span>
              <h2 className="mt-6 font-display text-3xl md:text-5xl tracking-tight text-primary">
                Création de site web pour associations
              </h2>
              <p className="mt-5 text-lg text-ink/70 leading-relaxed">
                Un site professionnel, livré en 5 jours, pensé pour les associations loi 1901. Moderne, sécurisé, hébergé en France — et vous gardez la main dessus.
              </p>
            </div>
          </Reveal>

          {/* Bénéfices */}
          <div className="mt-14 grid md:grid-cols-2 lg:grid-cols-3 gap-5 max-w-5xl mx-auto">
            {webBenefits.map((b, i) => (
              <Reveal key={b.text} delay={i * 60}>
                <div className="h-full card-premium p-5 flex items-start gap-4">
                  <div className="h-11 w-11 shrink-0 rounded-xl bg-gold/15 text-gold flex items-center justify-center">
                    <b.icon className="h-5 w-5" />
                  </div>
                  <p className="text-[15px] text-ink/85 font-sans leading-relaxed pt-1">
                    {b.text}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>

          {/* TARIFS — repris de la home */}
          <div className="mt-24">
            <Reveal>
              <SectionHeading
                eyebrow="Tarifs transparents"
                title="Une offre claire, tout compris"
                sub="Un forfait unique pour démarrer, et une option pour rester serein dans le temps."
              />
            </Reveal>

            <div className="grid lg:grid-cols-2 gap-7 mt-16 items-stretch max-w-5xl mx-auto">
              {/* ESSENTIEL */}
              <Reveal>
                <div className="relative h-full">
                  <div aria-hidden className="absolute -inset-1 rounded-[1.4rem] bg-gradient-to-br from-gold via-gold/40 to-primary/40 blur-md opacity-70 animate-gradient" />
                  <div className="relative h-full rounded-2xl p-8 md:p-10 bg-primary text-cream flex flex-col overflow-hidden">
                    <div aria-hidden className="absolute -top-32 -right-32 h-64 w-64 rounded-full bg-gold/30 blur-3xl" />
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gold text-gold-foreground text-xs font-sans font-bold uppercase tracking-wider px-4 py-1.5 rounded-full shadow-lg">
                      Notre offre phare
                    </span>
                    <h3 className="relative font-display text-3xl text-cream">Essentiel</h3>
                    <div className="relative mt-4 flex items-baseline gap-2">
                      <span className="font-display text-6xl font-bold text-gradient-gold">290€</span>
                      <span className="text-cream/70 font-sans text-sm">tout compris</span>
                    </div>
                    <p className="relative mt-3 text-cream/75 text-[15px]">
                      Paiement en 3× sans frais (3 × 97€) · Livraison en 5 jours
                    </p>
                    <ul className="relative mt-6 space-y-3 flex-1">
                      {[
                        "Site vitrine 5 pages (Accueil, Présentation, Équipe, Contact, Mentions légales)",
                        "Galerie photos (gérée en autonomie via Google Drive)",
                        "Agenda & calendrier événements",
                        "Formulaire de contact",
                        "Carte Google Maps",
                        "Liens réseaux sociaux",
                        "100% adapté mobile & tablette",
                        "Hébergement 1 an inclus",
                      ].map((f) => (
                        <li key={f} className="flex items-start gap-2.5 text-[15px]">
                          <Check className="h-5 w-5 shrink-0 mt-0.5 text-gold" />
                          <span>{f}</span>
                        </li>
                      ))}
                    </ul>
                    <Link to="/contact" className="relative mt-8 btn-gold w-full">
                      Obtenir ma maquette gratuite
                      <ArrowRight className="h-4 w-4" />
                    </Link>
                  </div>
                </div>
              </Reveal>

              {/* SÉRÉNITÉ */}
              <Reveal delay={120}>
                <div className="h-full card-premium p-8 md:p-10 flex flex-col">
                  <span className="chip !bg-sage/15 !text-sage !border-sage/30 w-fit">
                    Option recommandée
                  </span>
                  <h3 className="font-display text-3xl mt-4 text-primary">Option Sérénité</h3>
                  <div className="mt-4 flex items-baseline gap-2">
                    <span className="font-display text-6xl font-bold text-primary">29€</span>
                    <span className="text-muted-foreground font-sans">/mois</span>
                  </div>
                  <p className="mt-3 text-ink/65 text-[15px]">
                    Pour ne plus jamais avoir à vous soucier de votre site.
                  </p>
                  <ul className="mt-6 space-y-3 flex-1">
                    {[
                      "Modifications textes & design illimitées",
                      "Ajout de nouvelles pages",
                      "Support par téléphone & email",
                      "Modifications sous 48h ouvrées",
                      "Hébergement & sécurité inclus",
                    ].map((f) => (
                      <li key={f} className="flex items-start gap-2.5 text-[15px]">
                        <Check className="h-5 w-5 shrink-0 mt-0.5 text-sage" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                  <Link to="/contact" className="mt-8 btn-primary w-full">
                    Ajouter l'option Sérénité
                  </Link>
                </div>
              </Reveal>
            </div>

            <p className="mt-6 text-center text-xs text-ink/60 font-sans max-w-2xl mx-auto">
              L'offre Essentielle à 290€ est un paiement unique, sans abonnement. L'option Sérénité est facultative.
            </p>

            {/* À LA CARTE */}
            <div className="mt-20 max-w-3xl mx-auto">
              <Reveal>
                <SectionHeading
                  eyebrow="Sans abonnement"
                  title="Interventions à la carte"
                  sub="Vous préférez payer à l'acte ? Voici nos tarifs pour les interventions ponctuelles."
                />
              </Reveal>
              <Reveal>
                <div className="mt-10 rounded-2xl card-premium overflow-hidden">
                  <table className="w-full font-sans">
                    <tbody>
                      {[
                        ["Ajout / modification de texte", "25€"],
                        ["Modification design (couleurs, mise en page)", "45€"],
                        ["Ajout d'une nouvelle page", "80€"],
                      ].map(([label, price]) => (
                        <tr key={label} className="border-b border-border last:border-0 hover:bg-secondary/40 transition">
                          <td className="px-6 py-5 text-ink/85">{label}</td>
                          <td className="px-6 py-5 text-right font-display text-2xl text-primary font-bold">
                            {price}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <p className="text-center mt-6 text-[15px] text-ink/70 italic">
                  💡 L'option Sérénité à 29€/mois est rentable dès 2 interventions dans le mois.
                </p>
              </Reveal>
            </div>

          </div>
        </div>
      </section>

      {/* SÉPARATEUR */}
      <section className="py-12 bg-cream/40 border-y border-border">
        <div className="container-wide">
          <div className="flex items-center gap-6 max-w-3xl mx-auto">
            <div className="flex-1 h-px bg-border" />
            <p className="text-center font-display text-lg md:text-xl text-primary italic">
              Vous souhaitez également communiquer sur le terrain ?
            </p>
            <div className="flex-1 h-px bg-border" />
          </div>
        </div>
      </section>

      {/* SERVICE 2 — FLYERS & IMPRESSION */}
      <section className="py-24 relative">
        <div className="container-wide">
          <Reveal>
            <div className="max-w-3xl mx-auto text-center">
              <span className="chip"><FileImage className="h-3.5 w-3.5" /> Service n°2</span>
              <h2 className="mt-6 font-display text-3xl md:text-5xl tracking-tight text-primary">
                Flyers, affiches & impression pour vos événements
              </h2>
              <p className="mt-5 text-lg text-ink/70 leading-relaxed">
                Un visuel d'assemblée générale, une affiche de recrutement bénévoles, un flyer pour votre prochain événement… On s'occupe de la création graphique ET de l'impression, livrée directement chez vous.
              </p>
            </div>
          </Reveal>

          {/* Bénéfices print */}
          <div className="mt-14 grid md:grid-cols-2 lg:grid-cols-3 gap-5 max-w-5xl mx-auto">
            {printBenefits.map((b, i) => (
              <Reveal key={b.text} delay={i * 60}>
                <div className="h-full card-premium p-5 flex items-start gap-4">
                  <div className="h-11 w-11 shrink-0 rounded-xl bg-sage/15 text-sage flex items-center justify-center">
                    <b.icon className="h-5 w-5" />
                  </div>
                  <p className="text-[15px] text-ink/85 font-sans leading-relaxed pt-1">
                    {b.text}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>

          {/* TARIFS print */}
          <div className="mt-20">
            <Reveal>
              <SectionHeading
                eyebrow="Tarifs visuels"
                title="Tarifs — Visuels graphiques"
                sub="Des prix simples et clairs. L'impression est sur devis selon les quantités."
              />
            </Reveal>

            <div className="grid md:grid-cols-3 gap-6 mt-14 max-w-6xl mx-auto items-stretch">
              {/* Card 1 — Visuel seul */}
              <Reveal>
                <div className="h-full card-premium p-8 flex flex-col">
                  <h3 className="font-display text-2xl text-primary">Visuel seul</h3>
                  <div className="mt-4 flex items-baseline gap-2">
                    <span className="font-display text-5xl font-bold text-primary">29€</span>
                  </div>
                  <ul className="mt-6 space-y-3 flex-1">
                    {[
                      "Une affiche OU un flyer",
                      "Fichier prêt à imprimer",
                      "Livré sous 48h",
                    ].map((f) => (
                      <li key={f} className="flex items-start gap-2.5 text-[15px]">
                        <Check className="h-5 w-5 shrink-0 mt-0.5 text-sage" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                  <Link to="/contact" className="mt-8 btn-ghost w-full">
                    Demander mon visuel
                  </Link>
                </div>
              </Reveal>

              {/* Card 2 — Pack complet (featured) */}
              <Reveal delay={120}>
                <div className="relative h-full">
                  <div aria-hidden className="absolute -inset-1 rounded-[1.4rem] bg-gradient-to-br from-gold via-gold/40 to-primary/40 blur-md opacity-70 animate-gradient" />
                  <div className="relative h-full rounded-2xl p-8 bg-primary text-cream flex flex-col overflow-hidden">
                    <div aria-hidden className="absolute -top-32 -right-32 h-64 w-64 rounded-full bg-gold/30 blur-3xl" />
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gold text-gold-foreground text-xs font-sans font-bold uppercase tracking-wider px-4 py-1.5 rounded-full shadow-lg">
                      Le plus choisi
                    </span>
                    <h3 className="relative font-display text-2xl text-cream">Pack complet</h3>
                    <div className="relative mt-4 flex items-baseline gap-2">
                      <span className="font-display text-5xl font-bold text-gradient-gold">49€</span>
                    </div>
                    <ul className="relative mt-6 space-y-3 flex-1">
                      {[
                        "Affiche + flyer + visuel réseaux sociaux assortis",
                        "Même univers graphique, cohérent avec votre identité",
                        "Livré sous 48h",
                      ].map((f) => (
                        <li key={f} className="flex items-start gap-2.5 text-[15px]">
                          <Check className="h-5 w-5 shrink-0 mt-0.5 text-gold" />
                          <span>{f}</span>
                        </li>
                      ))}
                    </ul>
                    <Link to="/contact" className="relative mt-8 btn-gold w-full">
                      Demander mon visuel
                      <ArrowRight className="h-4 w-4" />
                    </Link>
                  </div>
                </div>
              </Reveal>

              {/* Card 3 — Design + impression livrée */}
              <Reveal delay={200}>
                <div className="h-full card-premium p-8 flex flex-col">
                  <h3 className="font-display text-2xl text-primary">Design + impression livrée</h3>
                  <div className="mt-4 flex items-baseline gap-2">
                    <span className="font-display text-4xl font-bold text-primary">Sur devis</span>
                  </div>
                  <p className="mt-2 text-ink/60 text-sm font-sans">
                    Tarif selon les quantités souhaitées
                  </p>
                  <ul className="mt-6 space-y-3 flex-1">
                    {[
                      "Pack complet inclus (affiche + flyer + visuel réseaux sociaux)",
                      "Impression prise en charge",
                      "Livraison directe chez vous",
                      "Quantité adaptée à votre événement",
                    ].map((f) => (
                      <li key={f} className="flex items-start gap-2.5 text-[15px]">
                        <Check className="h-5 w-5 shrink-0 mt-0.5 text-sage" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                  <Link to="/contact" className="mt-8 btn-ghost w-full">
                    Demander un devis impression
                  </Link>
                </div>
              </Reveal>
            </div>

            <p className="mt-8 text-center text-[15px] text-ink/65 italic max-w-2xl mx-auto">
              Vous avez déjà un site avec nous ? On utilise le même univers graphique pour tous vos visuels.
            </p>
          </div>
        </div>
      </section>

      {/* CTA FINAL */}
      <CTA />
    </>
  );
}

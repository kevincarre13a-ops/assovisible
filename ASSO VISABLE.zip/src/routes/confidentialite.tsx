import { createFileRoute, Link } from "@tanstack/react-router";
import { Reveal } from "@/components/Reveal";
import { ScrollText, Database, Target, Gavel, Clock, Share2, Cookie, UserCheck, Lock, RefreshCw, Mail, ChevronRight, CalendarDays } from "lucide-react";

export const Route = createFileRoute("/confidentialite")({
  head: () => ({
    meta: [
      { title: "Politique de confidentialité & RGPD | AssoVisible" },
      { name: "description", content: "Comment AssoVisible collecte, utilise et protège vos données personnelles en conformité RGPD. Exercez vos droits à tout moment, contactez notre équipe." },
      { property: "og:title", content: "Politique de confidentialité & RGPD | AssoVisible" },
      { property: "og:description", content: "Comment AssoVisible collecte, utilise et protège vos données personnelles en conformité RGPD. Exercez vos droits à tout moment, contactez notre équipe." },
    ],
  }),
  component: PrivacyPage,
});

const sections = [
  {
    id: "donnees",
    icon: Database,
    title: "1. Données collectées",
    content: (
      <>
        <p>Dans le cadre de son activité, AssoVisible est amenée à collecter les catégories de données personnelles suivantes :</p>
        <ul className="space-y-2 list-disc pl-5 mt-4">
          <li>Nom et prénom (si fournis volontairement)</li>
          <li>Adresse email</li>
          <li>Numéro de téléphone (si fourni)</li>
          <li>Messages et informations envoyés via le formulaire de contact</li>
          <li>Données de navigation (cookies, statistiques d'utilisation)</li>
        </ul>
        <p className="mt-4">Seules les données strictement nécessaires sont collectées, dans le respect du principe de minimisation prévu par le RGPD.</p>
      </>
    ),
  },
  {
    id: "finalites",
    icon: Target,
    title: "2. Finalité de la collecte",
    content: (
      <>
        <p>Les données collectées sont utilisées pour les finalités suivantes :</p>
        <ul className="space-y-2 list-disc pl-5 mt-4">
          <li>Répondre aux demandes de contact et aux questions des prospects</li>
          <li>Générer et qualifier des leads commerciaux</li>
          <li>Fournir les prestations de création de sites web et services digitaux</li>
          <li>Assurer la relation contractuelle avec les clients</li>
          <li>Améliorer le site, son contenu et ses performances</li>
          <li>Réaliser des statistiques de fréquentation anonymisées</li>
        </ul>
      </>
    ),
  },
  {
    id: "base-legale",
    icon: Gavel,
    title: "3. Base légale (RGPD)",
    content: (
      <>
        <p>Conformément au Règlement Général sur la Protection des Données (RGPD), le traitement de vos données repose sur les bases légales suivantes :</p>
        <ul className="space-y-2 list-disc pl-5 mt-4">
          <li><strong>Consentement</strong> de l'utilisateur, notamment pour l'envoi de messages via le formulaire de contact et le dépôt de cookies non essentiels</li>
          <li><strong>Intérêt légitime</strong> du responsable de traitement pour le suivi commercial et l'amélioration des services</li>
          <li><strong>Exécution contractuelle</strong> pour la fourniture des prestations souscrites par les clients</li>
        </ul>
      </>
    ),
  },
  {
    id: "conservation",
    icon: Clock,
    title: "4. Conservation des données",
    content: (
      <>
        <p>Les données personnelles sont conservées pendant la durée strictement nécessaire à la réalisation des finalités pour lesquelles elles ont été collectées :</p>
        <ul className="space-y-2 list-disc pl-5 mt-4">
          <li><strong>Prospects :</strong> 3 ans à compter du dernier contact</li>
          <li><strong>Clients :</strong> pendant toute la durée de la relation commerciale, puis 3 ans à des fins de prospection</li>
          <li><strong>Documents comptables :</strong> 10 ans conformément aux obligations légales</li>
          <li><strong>Cookies :</strong> 13 mois maximum</li>
        </ul>
        <p className="mt-4">Toute personne peut demander la suppression anticipée de ses données par simple email à <a href="mailto:contact@assovisible.fr" className="text-gold hover:underline">contact@assovisible.fr</a>.</p>
      </>
    ),
  },
  {
    id: "partage",
    icon: Share2,
    title: "5. Partage des données",
    content: (
      <>
        <p>AssoVisible s'engage à ne jamais vendre, louer ou céder vos données personnelles à des tiers à des fins commerciales.</p>
        <p className="mt-4">Vos données peuvent être partagées uniquement avec les prestataires techniques strictement nécessaires au fonctionnement du site et à la fourniture des services :</p>
        <ul className="space-y-2 list-disc pl-5 mt-4">
          <li>Hébergeur du site web</li>
          <li>Prestataire de messagerie email</li>
          <li>Outils d'analyse d'audience (statistiques)</li>
          <li>Éventuel CRM pour la gestion de la relation client</li>
        </ul>
        <p className="mt-4">Tous ces prestataires sont sélectionnés avec soin et présentent des garanties suffisantes en matière de sécurité et de respect du RGPD.</p>
      </>
    ),
  },
  {
    id: "cookies",
    icon: Cookie,
    title: "6. Cookies",
    content: (
      <>
        <p>Le site utilise des cookies afin d'améliorer votre expérience de navigation et de mesurer l'audience du site. Différents types de cookies peuvent être déposés :</p>
        <ul className="space-y-2 list-disc pl-5 mt-4">
          <li><strong>Cookies essentiels :</strong> nécessaires au fonctionnement du site</li>
          <li><strong>Cookies d'analyse :</strong> pour mesurer la fréquentation et améliorer l'UX</li>
          <li><strong>Cookies de préférences :</strong> pour mémoriser vos choix</li>
        </ul>
        <p className="mt-4">Le dépôt des cookies non essentiels est soumis à votre consentement préalable, recueilli via la bannière cookies affichée lors de votre première visite. Vous pouvez à tout moment modifier vos préférences ou retirer votre consentement.</p>
      </>
    ),
  },
  {
    id: "droits",
    icon: UserCheck,
    title: "7. Droits des utilisateurs",
    content: (
      <>
        <p>Conformément au RGPD et à la loi « Informatique et Libertés », vous disposez des droits suivants sur vos données personnelles :</p>
        <ul className="space-y-2 list-disc pl-5 mt-4">
          <li><strong>Droit d'accès</strong> à vos données</li>
          <li><strong>Droit de rectification</strong> des données inexactes</li>
          <li><strong>Droit à l'effacement</strong> (« droit à l'oubli »)</li>
          <li><strong>Droit d'opposition</strong> au traitement</li>
          <li><strong>Droit à la portabilité</strong> de vos données</li>
          <li><strong>Droit à la limitation</strong> du traitement</li>
          <li><strong>Droit de retirer votre consentement</strong> à tout moment</li>
        </ul>
        <p className="mt-4">Pour exercer ces droits, contactez-nous à <a href="mailto:contact@assovisible.fr" className="text-gold hover:underline">contact@assovisible.fr</a>. Une réponse vous sera apportée dans un délai maximum d'un mois. En cas de difficulté, vous pouvez introduire une réclamation auprès de la CNIL (<a href="https://www.cnil.fr" target="_blank" rel="noreferrer" className="text-gold hover:underline">cnil.fr</a>).</p>
      </>
    ),
  },
  {
    id: "securite",
    icon: Lock,
    title: "8. Sécurité",
    content: (
      <>
        <p>AssoVisible met en œuvre toutes les mesures techniques et organisationnelles appropriées pour garantir la sécurité, l'intégrité et la confidentialité de vos données personnelles, et notamment :</p>
        <ul className="space-y-2 list-disc pl-5 mt-4">
          <li>Chiffrement des communications via HTTPS / TLS</li>
          <li>Hébergement sécurisé chez un prestataire reconnu</li>
          <li>Accès aux données limité aux personnes habilitées</li>
          <li>Sauvegardes régulières et procédures de récupération</li>
          <li>Mises à jour de sécurité régulières</li>
        </ul>
      </>
    ),
  },
  {
    id: "modification",
    icon: RefreshCw,
    title: "9. Modification de la politique",
    content: (
      <>
        <p>La présente politique de confidentialité peut être amenée à évoluer à tout moment, notamment pour se conformer à toute évolution légale, réglementaire ou technique. La date de dernière mise à jour mentionnée en haut de page fait foi.</p>
        <p className="mt-4">Nous vous invitons à consulter régulièrement cette page pour prendre connaissance des éventuelles modifications.</p>
      </>
    ),
  },
];

function PrivacyPage() {
  return (
    <>
      <section className="relative py-20 md:py-28 mesh-bg grain overflow-hidden">
        <div aria-hidden className="absolute -top-20 right-1/4 h-72 w-72 rounded-full bg-gold/20 blur-3xl animate-blob" />
        <div aria-hidden className="absolute bottom-0 left-1/4 h-80 w-80 rounded-full bg-sage/15 blur-3xl animate-blob" style={{ animationDelay: "4s" }} />
        <div className="container-wide relative text-center max-w-3xl mx-auto">
          <span className="chip"><ScrollText className="h-3.5 w-3.5" /> Documents légaux</span>
          <h1 className="mt-6 font-display text-4xl md:text-5xl lg:text-6xl tracking-tight">
            Politique de <span className="text-gradient-gold">confidentialité</span>
          </h1>
          <p className="mt-5 text-lg md:text-xl text-ink/65 leading-relaxed">
            Comment nous collectons, utilisons et protégeons vos données personnelles, dans le respect du RGPD.
          </p>
          <div className="mt-6 inline-flex items-center gap-2 text-sm text-muted-foreground font-sans">
            <CalendarDays className="h-4 w-4" />
            Dernière mise à jour : 18 juin 2026
          </div>
        </div>
      </section>

      <section className="py-10 bg-secondary/30">
        <div className="container-prose max-w-4xl">
          <Reveal>
            <div className="bg-card border border-border rounded-xl p-6 md:p-8">
              <h2 className="font-display text-xl mb-4">Sommaire</h2>
              <nav className="grid sm:grid-cols-2 gap-2">
                {sections.map((s) => (
                  <a key={s.id} href={`#${s.id}`} className="flex items-center gap-2 py-1.5 px-3 rounded-md text-sm text-ink/80 hover:bg-primary/5 hover:text-primary transition-colors">
                    <ChevronRight className="h-3.5 w-3.5 text-gold shrink-0" />
                    {s.title}
                  </a>
                ))}
              </nav>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="container-prose max-w-3xl space-y-16">
          {sections.map((s, i) => {
            const Icon = s.icon;
            return (
              <Reveal key={s.id} delay={i % 3 === 0 ? 0 : i % 3 === 1 ? 40 : 80}>
                <article id={s.id} className="scroll-mt-28">
                  <div className="flex items-start gap-4 mb-5">
                    <div className="hidden sm:flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gold/10 text-gold">
                      <Icon className="h-5 w-5" />
                    </div>
                    <h2 className="font-display text-2xl md:text-3xl pt-0.5">{s.title}</h2>
                  </div>
                  <div className="prose prose-lg max-w-none text-ink/80 leading-relaxed font-serif">
                    {s.content}
                  </div>
                  {i < sections.length - 1 && <div className="mt-10 border-b border-border" />}
                </article>
              </Reveal>
            );
          })}
        </div>
      </section>

      <section className="py-20 bg-primary text-cream relative overflow-hidden grain">
        <div aria-hidden className="absolute -top-20 -right-20 h-72 w-72 rounded-full bg-gold/15 blur-3xl animate-blob" />
        <div aria-hidden className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full bg-sage/15 blur-3xl animate-blob" style={{ animationDelay: "5s" }} />
        <div className="container-wide relative text-center max-w-2xl mx-auto">
          <h2 className="font-display text-3xl md:text-4xl">Exercer vos droits</h2>
          <p className="mt-4 text-cream/75 text-lg">Une question sur vos données ? Nous vous répondons sous 48h.</p>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/contact" className="btn-gold">Nous contacter</Link>
            <a href="mailto:contact@assovisible.fr" className="btn-ghost !text-cream !border-cream/20 hover:!bg-cream/10">
              <Mail className="h-4 w-4" /> contact@assovisible.fr
            </a>
          </div>
        </div>
      </section>
    </>
  );
}

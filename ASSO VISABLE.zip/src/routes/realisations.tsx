import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowRight, TrendingUp, Users, Sparkles } from "lucide-react";
import { Reveal } from "@/components/Reveal";
import { SectionHeading } from "./index";
import portfolioCulture from "@/assets/portfolio-culture.jpg";
import portfolioSport from "@/assets/portfolio-sport.jpg";
import portfolioCharity from "@/assets/portfolio-charity.jpg";
import portfolioEnv from "@/assets/portfolio-env.jpg";
import portfolioEdu from "@/assets/portfolio-edu.jpg";
import portfolioHeritage from "@/assets/portfolio-heritage.jpg";
import portfolioMusic from "@/assets/portfolio-music.jpg";
import portfolioSenior from "@/assets/portfolio-senior.jpg";
import portfolioYouth from "@/assets/portfolio-youth.jpg";
import portfolioMontVal from "@/assets/portfolio-mont-val.png";
import portfolioKeravel from "@/assets/portfolio-keravel.png";
import portfolioAzur from "@/assets/portfolio-azur.png";

export const Route = createFileRoute("/realisations")({
  head: () => ({
    meta: [
      { title: "Réalisations — Sites web associatifs | AssoVisible" },
      { name: "description", content: "Découvrez les sites web créés pour 127 associations partout en France : design, fonctionnalités, résultats. Demandez votre maquette gratuite en 48h." },
      { property: "og:title", content: "Réalisations — Sites web associatifs | AssoVisible" },
      { property: "og:description", content: "Découvrez les sites web créés pour 127 associations partout en France : design, fonctionnalités, résultats. Demandez votre maquette gratuite en 48h." },
    ],
  }),
  component: PortfolioPage,
});

const projects = [
  { img: portfolioMontVal, name: "Solidarité Montreval", cat: "Caritatives", region: "Montreval", services: "Site vitrine + Module de dons + Espace bénévoles", url: "https://mont-val-solidarite.lovable.app" },
  { img: portfolioKeravel, name: "Les Ateliers de Keravel", cat: "Culturelles", region: "Keravel, Bretagne", services: "Site vitrine + Galerie + Adhésion en ligne", url: "https://keravel-maritime-culture.lovable.app" },
  { img: portfolioAzur, name: "Azur Fitness Club", cat: "Sportives", region: "Marseille, Bouches-du-Rhône", services: "Site + Planning + Espace membre", url: "https://azur-fit-connect.lovable.app" },
  { img: portfolioCulture, name: "Les Arts du Quercy", cat: "Culturelles", region: "Cahors, Lot", services: "Site vitrine + Agenda" },
  { img: portfolioSport, name: "Courir à Bordeaux", cat: "Sportives", region: "Bordeaux, Gironde", services: "Inscriptions + Espace adhérents" },
  { img: portfolioCharity, name: "Solidarité Auvergne", cat: "Caritatives", region: "Clermont-Ferrand, Puy-de-Dôme", services: "Site + Module de dons" },
  { img: portfolioEnv, name: "Forêts d'Avenir", cat: "Environnement", region: "Rennes, Ille-et-Vilaine", services: "Site vitrine + Newsletter" },
  { img: portfolioEdu, name: "Lire Ensemble", cat: "Éducation", region: "Lille, Nord", services: "Site + Espace ressources" },
  { img: portfolioHeritage, name: "Mémoire de Provence", cat: "Culturelles", region: "Aix-en-Provence, Bouches-du-Rhône", services: "Site + Billetterie visites" },
  { img: portfolioMusic, name: "Harmonie de Bourgogne", cat: "Culturelles", region: "Dijon, Côte-d'Or", services: "Site vitrine + Agenda concerts" },
  { img: portfolioSenior, name: "Pétanque Club du Sud", cat: "Sportives", region: "Montpellier, Hérault", services: "Site + Calendrier tournois" },
  { img: portfolioYouth, name: "Jeunesse Solidaire", cat: "Caritatives", region: "Lyon, Rhône", services: "Site + Espace bénévoles" },
];

const cats = ["Tous", "Culturelles", "Sportives", "Caritatives", "Environnement", "Éducation"] as const;

function PortfolioPage() {
  const [active, setActive] = useState<(typeof cats)[number]>("Tous");
  const filtered = active === "Tous" ? projects : projects.filter((p) => p.cat === active);

  return (
    <>
      <section className="relative py-24 mesh-bg grain overflow-hidden">
        <div aria-hidden className="absolute -top-20 left-1/4 h-72 w-72 rounded-full bg-gold/25 blur-3xl animate-blob" />
        <div aria-hidden className="absolute bottom-0 right-1/4 h-80 w-80 rounded-full bg-sage/20 blur-3xl animate-blob" style={{ animationDelay: "4s" }} />
        <div className="container-wide relative text-center max-w-3xl mx-auto">
          <span className="chip"><Sparkles className="h-3.5 w-3.5" /> Portfolio</span>
          <h1 className="mt-6 font-display text-5xl md:text-6xl lg:text-7xl tracking-tight">
            Une <span className="text-gradient-gold">communauté</span> qui rayonne
          </h1>
          <p className="mt-6 text-lg md:text-xl text-ink/65 leading-relaxed">
            Découvrez les sites créés pour des associations partout en France — chaque projet est unique, conçu sur mesure.
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="container-wide">
          <div className="flex flex-wrap justify-center gap-2 mb-12">
            {cats.map((c) => (
              <button
                key={c}
                onClick={() => setActive(c)}
                className={`font-sans text-sm font-semibold px-5 py-2.5 rounded-full border transition ${
                  active === c
                    ? "bg-primary text-cream border-primary shadow-soft"
                    : "bg-card border-border text-ink/70 hover:border-gold hover:text-primary"
                }`}
              >
                {c}
              </button>
            ))}
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-7">
            {filtered.map((p, i) => (
              <Reveal key={p.name} delay={i * 60}>
                <article className="group rounded-2xl overflow-hidden card-premium">
                  <div className="aspect-[4/3] overflow-hidden bg-muted relative">
                    <img
                      src={p.img}
                      alt={p.name}
                      loading="lazy"
                      className="w-full h-full object-cover group-hover:scale-110 transition duration-[900ms]"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-primary/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition" />
                    <span className="absolute top-4 left-4 chip !bg-cream/90 !text-primary !border-cream">
                      {p.cat}
                    </span>
                  </div>
                  <div className="p-6">
                    <h2 className="font-display text-xl text-primary">{p.name}</h2>
                    <p className="text-sm text-muted-foreground mt-1 font-sans">{p.region}</p>
                    <p className="text-[15px] text-ink/70 mt-3">{p.services}</p>
                    {p.url && (
                      <a href={p.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 mt-4 font-sans text-sm font-semibold text-primary group-hover:text-gold transition">
                        Voir le projet <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                      </a>
                    )}
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* CASE STUDY */}
      <section className="py-24 bg-secondary/40">
        <div className="container-prose">
          <Reveal>
            <SectionHeading eyebrow="Étude de cas" title="Forêts d'Avenir : refonte complète" />
          </Reveal>
          <div className="mt-14 grid lg:grid-cols-2 gap-12 items-center">
            <Reveal>
              <div className="rounded-xl overflow-hidden border border-border shadow-elegant">
                <img src={portfolioEnv} alt="Site Forêts d'Avenir" loading="lazy" className="w-full h-full object-cover" />
              </div>
            </Reveal>
            <Reveal delay={100}>
              <div>
                <h3 className="font-display text-2xl text-primary">Le défi</h3>
                <p className="mt-3 text-ink/75">
                  Une association de protection de la forêt avec un site obsolète et impossible à mettre à jour.
                  Aucun moyen de collecter des dons en ligne malgré une forte demande.
                </p>
                <h3 className="font-display text-2xl text-primary mt-8">Notre solution</h3>
                <p className="mt-3 text-ink/75">
                  Refonte complète du site, intégration d'un module de dons sécurisé,
                  newsletter automatisée, et formation de l'équipe pour une autonomie totale.
                </p>
                <div className="mt-10 grid grid-cols-2 gap-4">
                  <div className="rounded-lg bg-card p-6 border border-border">
                    <TrendingUp className="h-6 w-6 text-sage" />
                    <div className="font-display text-3xl text-primary mt-3">+340%</div>
                    <div className="text-sm text-muted-foreground font-sans">de visites en 6 mois</div>
                  </div>
                  <div className="rounded-lg bg-card p-6 border border-border">
                    <Users className="h-6 w-6 text-sage" />
                    <div className="font-display text-3xl text-primary mt-3">+60</div>
                    <div className="text-sm text-muted-foreground font-sans">nouveaux adhérents</div>
                  </div>
                </div>
                <blockquote className="mt-8 border-l-4 border-gold pl-5 italic text-ink/80">
                  « AssoVisible a transformé notre présence en ligne. Nous avons enfin un outil à la hauteur de notre mission. »
                  <footer className="mt-2 not-italic font-sans text-sm text-muted-foreground">
                    — Sophie R., Secrétaire de Forêts d'Avenir
                  </footer>
                </blockquote>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      <CTA />
    </>
  );
}

export function CTA() {
  return (
    <section className="py-24">
      <div className="container-wide">
        <div className="relative rounded-3xl overflow-hidden mesh-bg-dark text-cream p-12 md:p-16 text-center grain">
          <div aria-hidden className="absolute -top-20 -left-20 h-80 w-80 rounded-full bg-gold/25 blur-3xl animate-blob" />
          <div aria-hidden className="absolute -bottom-20 -right-20 h-80 w-80 rounded-full bg-sage/20 blur-3xl animate-blob" style={{ animationDelay: "5s" }} />
          <div className="relative max-w-2xl mx-auto">
            <span className="chip !bg-gold/20 !text-gold !border-gold/40">
              <Sparkles className="h-3.5 w-3.5" /> Devis gratuit
            </span>
            <h2 className="font-display text-cream text-4xl md:text-5xl mt-5 leading-tight">
              Parlons de votre <span className="text-gradient-gold">projet</span>
            </h2>
            <p className="mt-5 text-cream/75 text-lg">
              Premier échange toujours gratuit, sans engagement. Réponse sous 24h ouvrées.
            </p>
            <Link to="/contact" className="mt-9 btn-gold inline-flex">
              Demander un devis gratuit
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
